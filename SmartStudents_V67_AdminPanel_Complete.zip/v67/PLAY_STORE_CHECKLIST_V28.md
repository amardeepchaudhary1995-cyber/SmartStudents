# Play Store Checklist — V28

- [ ] Signed release AAB generated
- [ ] Version code/name verified
- [ ] Firebase production project connected
- [ ] Production Firestore/Storage rules deployed
- [ ] Cloud Functions deployed
- [ ] FCM tested
- [ ] Crashlytics/Analytics tested
- [ ] Privacy policy published
- [ ] Data Safety form completed
- [ ] Content rating completed
- [ ] Target audience completed
- [ ] Store icon/screenshots prepared
- [ ] Internal testing track passed
- [ ] Closed testing/release review passed
- [ ] Production rollout approved
