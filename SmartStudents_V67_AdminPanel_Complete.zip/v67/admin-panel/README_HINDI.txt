SmartStudents V67 - Firebase Admin Panel

यह Admin Panel V67 के मौजूदा Firestore structure के हिसाब से बनाया गया है:
- courses/{courseId}
- courses/{courseId}/chapters/{chapterId}
- courses/{courseId}/chapters/{chapterId}/lessons/{lessonId}
- courses/{courseId}/chapters/{chapterId}/lessons/{lessonId}/questions/{questionId}
- announcements/{announcementId}
- users/{uid} में role = ADMIN

सेटअप:
1. Firebase Console में Web App बनाएं/खोलें और Firebase config लें।
2. index.html में const firebaseConfig के PASTE_FIREBASE_CONFIG values को अपनी values से बदलें।
3. Firebase Authentication में Email/Password enable करें।
4. Admin user बनाएं।
5. Firestore में users/{ADMIN_UID} document रखें और role: "ADMIN" दें।
6. इस admin-panel folder को GitHub Pages/hosting पर deploy करें।

ध्यान दें: Security Rules में ADMIN write access जरूर रखें। यह panel client-side Firebase SDK इस्तेमाल करता है; secret key HTML में नहीं डालनी होती।
