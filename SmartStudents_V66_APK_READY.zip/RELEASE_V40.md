# Smart Students V40

## Release hardening

- Fixed missing `FirebaseSecurity` import in `MainActivity.kt`.
- Fixed GitHub Actions release signing workflow so the keystore base64 secret is actually available to the shell that decodes it.
- Configured CI to use Gradle 8.9 explicitly for reproducible builds.
- Version bumped to V40 / versionCode 40.
- Kept production credentials out of the repository.

## Verification

- Static release gate: PASS.
- Production preflight: PASS.
- Firebase Functions Node syntax check: PASS.
- Android APK/AAB compilation cannot be verified in this environment because the Android SDK is not installed.

## CI release requirements

Configure these GitHub Actions secrets before a signed AAB build:

- `SMARTSTUDENTS_KEYSTORE_BASE64`
- `SMARTSTUDENTS_KEYSTORE_PASSWORD`
- `SMARTSTUDENTS_KEY_ALIAS`
- `SMARTSTUDENTS_KEY_PASSWORD`
- `GOOGLE_SERVICES_JSON_B64`
