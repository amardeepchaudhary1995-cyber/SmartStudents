# Smart Students V49 — One-Run Production Release

V49 turns the existing release candidate into a single GitHub Actions production handoff.

## What is automated
- Release gate, production preflight and final smoke checks.
- Signed production AAB build.
- Firebase Firestore/Storage rules + Cloud Functions deployment.
- Optional Google Play Internal testing upload.
- Temporary credentials are removed after the job.

## Required GitHub secrets
- `SMARTSTUDENTS_KEYSTORE_BASE64`
- `SMARTSTUDENTS_KEYSTORE_PASSWORD`
- `SMARTSTUDENTS_KEY_ALIAS`
- `SMARTSTUDENTS_KEY_PASSWORD`
- `GOOGLE_SERVICES_JSON_B64`
- `FIREBASE_SERVICE_ACCOUNT_JSON`
- `FIREBASE_PROJECT_ID`
- `GOOGLE_PLAY_SERVICE_ACCOUNT_JSON` (only for Play upload)

## Final limitation
The release cannot be executed from this offline build environment because Firebase and Google Play accounts require the owner's credentials and authorization. Once those secrets exist in the repository, the workflow can perform the production deployment and internal-track upload from one manual workflow run.
