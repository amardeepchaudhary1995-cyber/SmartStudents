# SmartStudents V50 — Release Now

V50 is the release-candidate packaging. No feature-development step is required before the release workflow.

## One workflow

GitHub Actions → **Android build** → **Run workflow**:

- `build_release = true`
- `deploy_firebase = true`
- `publish_internal = true` when the Google Play service account is ready

The workflow will:

1. run release/preflight/source smoke gates;
2. verify signing + Google Services secrets;
3. build the signed production AAB;
4. verify Firebase credentials and deploy Firestore rules, Storage rules and Functions;
5. verify Google Play credentials and upload the AAB to **Internal testing** when requested;
6. upload the signed AAB as a workflow artifact;
7. remove temporary Firebase/signing files.

## Required GitHub secrets

### Android build
- `SMARTSTUDENTS_KEYSTORE_BASE64`
- `SMARTSTUDENTS_KEYSTORE_PASSWORD`
- `SMARTSTUDENTS_KEY_ALIAS`
- `SMARTSTUDENTS_KEY_PASSWORD`
- `GOOGLE_SERVICES_JSON_B64`

### Firebase deployment
- `FIREBASE_SERVICE_ACCOUNT_JSON`
- `FIREBASE_PROJECT_ID`

### Google Play Internal testing
- `GOOGLE_PLAY_SERVICE_ACCOUNT_JSON`

## Final release gate

After Internal testing QA passes on a physical device, use the same AAB in Play Console for the production rollout. The workflow cannot bypass Google Play/Firebase account authorization or Play Console policy/forms.

## Important

Do not commit any service-account JSON, keystore, password, or `google-services.json` file. The workflow writes these only temporarily and deletes them at the end.
