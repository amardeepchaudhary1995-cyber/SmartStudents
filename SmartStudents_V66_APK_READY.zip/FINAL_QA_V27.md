# Smart Students V27 — Final Security & QA

## What V27 hardens
- Firestore progress documents are read-only from Android clients.
- Course/lesson/question writes require the Firebase `admin=true` custom claim.
- Student profile updates cannot change `parentUid` from the client.
- Parent-child records are no longer client-writable.
- Parent link creation must belong to the student creating the code.
- Published content remains readable only when the course is published.
- Storage writes/deletes remain admin-only.
- Announcement push is sent both when an announcement is created already-published and when a draft is later published.
- Offline/demo mode remains available when Firebase is not configured.

## Required production checks

### Firebase
- [ ] Use a separate Firebase project for production.
- [ ] Enable Email/Password Authentication.
- [ ] Deploy `firestore.rules` and `storage.rules`.
- [ ] Deploy Functions with Node 20.
- [ ] Give only trusted staff the `admin=true` custom claim.
- [ ] Enable App Check before public launch and enforce it after testing.
- [ ] Verify Analytics and Crashlytics in Firebase console.

### Account/security tests
- [ ] Student cannot write `users/*/progress/*`.
- [ ] Student cannot create/update/delete courses.
- [ ] Student cannot upload/delete Storage media.
- [ ] Student cannot change another user's `parentUid`.
- [ ] Parent cannot write another parent's child list.
- [ ] Unpublished courses are invisible to students.
- [ ] A used/invalid parent code cannot be reused.
- [ ] Admin access is denied when the custom claim is absent.

### Learning tests
- [ ] Complete a lesson offline, kill the app, reopen, reconnect and verify sync.
- [ ] Submit the same lesson twice; completion count must not increase twice.
- [ ] Submit a fake lesson ID; server must ignore it.
- [ ] Submit a quiz score above 100%; server must clamp it.
- [ ] Verify best score never decreases.
- [ ] Verify a course's real lesson count is used.

### Push tests
- [ ] Fresh install grants notification permission on Android 13+.
- [ ] Device receives a newly created published announcement.
- [ ] Device receives a draft announcement only when it is later published.
- [ ] Foreground notification appears correctly.
- [ ] Tapping a notification does not crash the app.

### Release tests
- [ ] Test on Android 8, 10, 12 and 14/15+ where possible.
- [ ] Test poor network and airplane mode.
- [ ] Verify no test credentials are shipped.
- [ ] Verify `google-services.json` is the production project's file.
- [ ] Run `./gradlew clean test` and `./gradlew assembleRelease`.
- [ ] Build a signed AAB only after all Firebase checks pass.

## App Check recommendation
Use Play Integrity/App Check for the production Android app. Roll it out in monitoring mode first, verify legitimate traffic, then enforce it.

## Important
The ZIP intentionally does not contain a Firebase service-account key or production `google-services.json`.


## V28 release gate
All QA items must pass on the signed release AAB before Play Store submission.
