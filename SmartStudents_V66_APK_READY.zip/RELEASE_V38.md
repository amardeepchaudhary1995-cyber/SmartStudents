# Smart Students V38 — Release Candidate Hardening

V38 focuses on a real Android deployment blocker found during source review.

## Fixed
- Added `android.permission.INTERNET` to the Android manifest. Firebase Authentication, Firestore, Storage, Functions and FCM require network access in the installed app.
- Bumped versionCode to 38 and VERSION to V38.
- Extended the release gate to fail if the INTERNET permission is missing.

## Verification
- Static release gate passes.
- Firebase Functions Node syntax check passes when Node is available.
- Credential/secret-file checks remain enabled.
- This environment does not contain the Android SDK/Gradle wrapper, so an actual APK/AAB compile must be performed in Android Studio or CI.

## Production gate still required
1. Add the real Firebase `google-services.json` locally/through CI secret handling.
2. Deploy Firestore, Storage and Cloud Functions.
3. Configure App Check / Play Integrity.
4. Configure a release keystore through CI secrets.
5. Build a signed AAB.
6. Install the release build on physical Android devices and test Auth, offline sync, media, notifications, parent linking and account deletion.
