# Smart Students V35 — Production Build & Backend Hardening

## Completed
- Kotlin 2 Compose compiler plugin is explicitly configured for reliable release builds.
- CI workflow paths now target the repository root instead of the legacy `ss15` directory.
- Release gate checks V35/versionCode 35.
- Parent link codes use cryptographically secure random bytes and expire after 24 hours.
- Parent-link transactions re-check expiry and one-time usage server-side.
- Account deletion batches Firestore deletes in chunks below the 500-write limit.
- Existing App Check, progress validation, FCM, Crashlytics, Analytics and deletion protections remain enabled.

## Still required outside this source package
1. Add production `google-services.json` through CI secrets or Firebase setup.
2. Configure Play Integrity/App Check for the real Android package/signing certificate.
3. Configure release keystore secrets.
4. Run the GitHub Actions debug build and signed AAB build.
5. Install the AAB-derived build on physical devices and complete final QA.
6. Complete Play Console Data Safety, privacy policy URL, content rating and store listing.
