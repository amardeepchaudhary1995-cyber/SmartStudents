# SmartStudents V60 — Release Candidate Gate

V60 makes the release pipeline fail-safe: the signed AAB is generated, hashed, checksum-verified, and recorded in an immutable manifest **before** Firebase or Google Play publishing is allowed. Temporary production credentials are cleaned up at the end of the job even when a later step fails.

## Release path
1. Release gate / preflight / smoke
2. Signed production AAB
3. AAB + SHA-256 verification
4. Immutable release manifest
5. External publish (Firebase / Play Internal)
6. Artifact upload
7. Credential cleanup
