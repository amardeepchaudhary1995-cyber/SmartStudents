# SmartStudents V61 — Release Candidate Lock

V61 keeps the V60 release pipeline and adds an exact-artifact publish lock.

## Release safety
- Signed AAB is checksum-verified before external publish.
- Immutable manifest records the exact AAB filename and SHA-256.
- Play Internal Testing receives a copied `PLAY-PUBLISH.aab` whose SHA-256 is rechecked immediately before upload.
- Firebase and Play publishing remain gated behind the verified release candidate.

## Status
- Source release gate: PASS
- Production preflight: PASS (local Gradle wrapper warning remains)
- Final source smoke: PASS

Actual Play/Firebase deployment still requires the configured production credentials in GitHub Actions.
