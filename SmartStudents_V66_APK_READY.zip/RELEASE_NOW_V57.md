# SmartStudents V57 — Release Candidate

V57 is a release-focused battery/network efficiency pass.

## Changes
- Debounces foreground network-recovery progress flushes for 30 seconds.
- Keeps network observation limited to the visible Activity lifecycle.
- Resets the debounce state when the Activity stops.
- Keeps the signed AAB, Firebase deployment, Play Internal Testing, checksum, and immutable manifest pipeline unchanged.

## Validation
Run `python3 scripts/release_gate.py`, `python3 scripts/production_preflight.py`, `python3 scripts/release_readiness.py`, and `python3 scripts/final_smoke.py` before the production workflow.

## Release path
GitHub Actions → signed AAB → Firebase production backend (optional input) → Google Play Internal Testing → physical QA → Production.
