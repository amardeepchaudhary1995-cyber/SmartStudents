# Smart Students — Privacy Policy Draft

**Last updated:** 24 October 2026

This draft is a starting point for the app owner. Replace the bracketed contact details and have the final policy reviewed before publishing.

## Information used by the app
Smart Students may process:
- account information such as name and email when Firebase Authentication is enabled;
- learning progress, lesson completion and quiz scores;
- parent/student linking information;
- course and announcement content;
- device notification token/topic subscription for push notifications;
- diagnostic information and crash reports when Firebase Analytics/Crashlytics are enabled.

## Why information is used
Information is used to authenticate users, provide courses, save learning progress, connect parent and student accounts, send important announcements, and diagnose app reliability.

## Service providers
When enabled, the app uses Google Firebase services including Authentication, Firestore, Storage, Cloud Functions, Cloud Messaging, Analytics and Crashlytics.

## Data retention and deletion
The app owner should define retention periods and provide an account/data deletion process. Users should be able to request deletion of their account and associated personal data, subject to legitimate legal or operational requirements.

## Children
If the service is offered to children, the app owner must configure the target audience, parental controls and consent process appropriate to the jurisdictions in which the service is offered. This draft does not itself establish legal compliance.

## Contact
Replace with the operator's support contact before publishing:

**Email:** [support@example.com]

## Changes
The app owner should publish a dated notice when this policy materially changes.
