# SmartStudents V54 — Release Now

V54 is the release-speed hardening step. Manual production releases now skip the debug APK build by default and go directly through release gate → signed AAB → Firebase production deployment → Google Play Internal Testing.

## GitHub Actions

Run **Android release** with:
- `build_release=true`
- `deploy_firebase=true`
- `publish_internal=true`
- `run_debug_smoke=false` (default)

Turn `run_debug_smoke=true` only when a debug APK is specifically needed for QA.

## Release result

The workflow produces the signed AAB, SHA-256 checksum and immutable release manifest as artifacts. It can publish the same AAB to Play Internal Testing.

## Final production step

After Internal Testing device QA passes, promote the tested release in Google Play Console. This repository does not claim a public production rollout until the owner completes that Play Console action.
