const {onCall, HttpsError} = require("firebase-functions/v2/https");
const {onDocumentCreated, onDocumentUpdated} = require("firebase-functions/v2/firestore");
const {getMessaging} = require("firebase-admin/messaging");
const {initializeApp} = require("firebase-admin/app");
const {getAuth} = require("firebase-admin/auth");
const {getFirestore, FieldValue} = require("firebase-admin/firestore");
const crypto = require("node:crypto");
initializeApp();
const db = getFirestore();

exports.submitProgress = onCall({enforceAppCheck: true}, async (request) => {
  if (!request.auth) throw new HttpsError("unauthenticated", "Login required.");
  const data = request.data || {};
  const uid = request.auth.uid;
  const courseId = String(data.courseId || "");
  const requestedIds = Array.isArray(data.completedLessonIds)
    ? data.completedLessonIds.map(String).filter(Boolean) : [];
  const requestedScore = Number.isFinite(Number(data.bestQuizPercentage))
    ? Math.max(0, Math.min(100, Number(data.bestQuizPercentage))) : 0;
  if (!courseId) throw new HttpsError("invalid-argument", "courseId is required.");

  const courseRef = db.collection("courses").doc(courseId);
  const courseSnap = await courseRef.get();
  if (!courseSnap.exists || courseSnap.data().published !== true) {
    throw new HttpsError("permission-denied", "Course is not published.");
  }

  const chapters = await courseRef.collection("chapters").get();
  const validIds = new Set();
  for (const chapter of chapters.docs) {
    const lessons = await chapter.ref.collection("lessons").get();
    lessons.docs.forEach(doc => validIds.add(doc.id));
  }
  const completed = [...new Set(requestedIds)].filter(id => validIds.has(id));
  const totalLessons = validIds.size;

  const progressRef = db.collection("users").doc(uid).collection("progress").doc(courseId);
  const current = await progressRef.get();
  const currentScore = current.exists ? Number(current.data().bestQuizPercentage || current.data().bestScore || 0) : 0;
  const bestQuizPercentage = Math.max(currentScore, requestedScore);

  await progressRef.set({
    uid, courseId, completedLessons: completed.length, totalLessons,
    bestQuizPercentage, completedLessonIds: completed,
    updatedAt: FieldValue.serverTimestamp()
  }, {merge:true});

  return {completedLessons: completed.length, totalLessons, bestQuizPercentage};
});


/**
 * Sends every newly published announcement to the student topic.
 * Only documents created with published=true are delivered.
 */
async function sendAnnouncementNotification(event) {
  const after = event.data?.after?.data?.();
  const created = event.data?.data?.();
  const data = after || created;
  if (!data || data.published !== true) return null;

  // On updates, notify only when the announcement becomes published.
  if (after && event.data.before) {
    const before = event.data.before.data();
    if (before?.published === true) return null;
  }

  const title = String(data.title || "Smart Students");
  const body = String(data.body || "");
  return getMessaging().send({
    topic: "all_students",
    notification: { title, body },
    data: {
      type: "announcement",
      announcementId: event.params.announcementId,
      title: title.slice(0, 200),
      body: body.slice(0, 1000)
    },
    android: { notification: { channelId: "smart_students_announcements" } }
  });
}

exports.notifyNewAnnouncement = onDocumentCreated(
  "announcements/{announcementId}",
  sendAnnouncementNotification
);

exports.notifyPublishedAnnouncement = onDocumentUpdated(
  "announcements/{announcementId}",
  sendAnnouncementNotification
);


/**
 * Creates a one-time student -> parent link code.
 * Code generation happens on the trusted backend to avoid client-side
 * collisions and to keep ownership authoritative.
 */
exports.createParentLinkCode = onCall({enforceAppCheck: true}, async (request) => {
  if (!request.auth) throw new HttpsError("unauthenticated", "Login required.");
  const uid = request.auth.uid;
  const ref = db.collection("parentLinks");
  for (let i = 0; i < 8; i++) {
    const code = crypto.randomBytes(4).toString("hex").slice(0, 6).toUpperCase();
    const codeRef = ref.doc(code);
    const snap = await codeRef.get();
    if (!snap.exists) {
      await codeRef.create({
        studentUid: uid,
        used: false,
        createdAt: FieldValue.serverTimestamp(),
        expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000)
      });
      return {code};
    }
  }
  throw new HttpsError("resource-exhausted", "Could not create a unique link code. Try again.");
});

/**
 * Atomically links a parent account to a student using the one-time code.
 * Client Firestore writes cannot directly modify parentUid or child records.
 */
exports.linkParentToStudent = onCall({enforceAppCheck: true}, async (request) => {
  if (!request.auth) throw new HttpsError("unauthenticated", "Login required.");
  const parentUid = request.auth.uid;
  const code = String(request.data?.code || "").trim().toUpperCase();
  if (!/^[A-Z0-9]{6}$/.test(code)) {
    throw new HttpsError("invalid-argument", "Enter a valid 6-character code.");
  }

  const linkRef = db.collection("parentLinks").doc(code);
  const parentRef = db.collection("users").doc(parentUid);
  const linkSnap = await linkRef.get();
  if (!linkSnap.exists) throw new HttpsError("not-found", "Invalid link code.");

  const link = linkSnap.data() || {};
  if (link.used === true) throw new HttpsError("failed-precondition", "This code has already been used.");
  if (link.expiresAt && link.expiresAt.toDate && link.expiresAt.toDate().getTime() < Date.now()) {
    throw new HttpsError("deadline-exceeded", "This link code has expired.");
  }
  const studentUid = String(link.studentUid || "");
  if (!studentUid || studentUid === parentUid) {
    throw new HttpsError("invalid-argument", "Invalid student link.");
  }

  await db.runTransaction(async tx => {
    const fresh = await tx.get(linkRef);
    if (!fresh.exists || fresh.data()?.used === true) {
      throw new HttpsError("failed-precondition", "This code has already been used.");
    }
    const freshData = fresh.data() || {};
    if (freshData.expiresAt?.toDate && freshData.expiresAt.toDate().getTime() < Date.now()) {
      throw new HttpsError("deadline-exceeded", "This link code has expired.");
    }
    const studentRef = db.collection("users").doc(studentUid);
    const studentSnap = await tx.get(studentRef);
    if (!studentSnap.exists) throw new HttpsError("not-found", "Student account not found.");
    const existingParent = studentSnap.data()?.parentUid;
    if (existingParent && existingParent !== parentUid) {
      throw new HttpsError("already-exists", "Student is already linked to another parent.");
    }

    tx.set(parentRef.collection("children").doc(studentUid), {
      studentUid,
      linkedAt: FieldValue.serverTimestamp()
    });
    tx.update(studentRef, {parentUid});
    tx.update(linkRef, {
      used: true,
      parentUid,
      linkedAt: FieldValue.serverTimestamp()
    });
  });

  return {linked: true, studentUid};
});


/**
 * GDPR/Play-Console friendly account deletion endpoint.
 * Deletes only the authenticated user's Firebase Auth account and user-owned
 * Firestore data. Admin-owned course content is never touched.
 */
exports.deleteMyAccount = onCall({enforceAppCheck: true}, async (request) => {
  if (!request.auth) throw new HttpsError("unauthenticated", "Login required.");
  const uid = request.auth.uid;
  const userRef = db.collection("users").doc(uid);

  // Remove the user's progress and profile subcollections atomically via
  // Admin SDK recursive delete, then remove parent-link documents referring
  // to this account.
  await db.recursiveDelete(userRef);

  // Remove one-time link records that reference the deleted account.
  const links = await db.collection("parentLinks").get();
  let pending = [];
  for (const doc of links.docs) {
    const data = doc.data() || {};
    if (data.studentUid === uid || data.parentUid === uid) {
      pending.push(doc.ref);
      if (pending.length === 450) {
        const batch = db.batch();
        pending.forEach(ref => batch.delete(ref));
        await batch.commit();
        pending = [];
      }
    }
  }
  if (pending.length) {
    const batch = db.batch();
    pending.forEach(ref => batch.delete(ref));
    await batch.commit();
  }

  // If the deleted account was a student, remove the child reference from
  // the parent's children subcollection as well.
  const childRefs = await db.collectionGroup("children")
      .where("studentUid", "==", uid).get();
  if (!childRefs.empty) {
    let pending = [];
    for (const doc of childRefs.docs) {
      pending.push(doc.ref);
      if (pending.length === 450) {
        const childBatch = db.batch();
        pending.forEach(ref => childBatch.delete(ref));
        await childBatch.commit();
        pending = [];
      }
    }
    if (pending.length) {
      const childBatch = db.batch();
      pending.forEach(ref => childBatch.delete(ref));
      await childBatch.commit();
    }
  }

  await getAuth().deleteUser(uid);
  return {deleted: true};
});
