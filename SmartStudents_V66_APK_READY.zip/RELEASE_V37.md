# Smart Students V37 Release Notes

V37 is a security-hardening release focused on preventing privilege/ownership fields from being injected during first-time profile creation.

## Changes
- Firestore user creation now explicitly rejects client-supplied `parentUid`.
- Version code updated to 37.
- Release gate and production preflight updated for V37.
- Added `.gitignore` protections for Firebase config, service-account credentials and signing keystores.

## Verification
- Release Gate: PASS
- Production Preflight: PASS
- Firebase Functions Node syntax check: PASS

This is still a source-level verification. A real signed AAB must be built in Android Studio/CI with the production Firebase configuration and release keystore.
