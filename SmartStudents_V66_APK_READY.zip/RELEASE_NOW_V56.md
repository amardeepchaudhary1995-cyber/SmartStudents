# SmartStudents V56 — Release Now

V56 adds a final checksum verification immediately before release provenance is generated. The immutable manifest also records the GitHub workflow run ID.

Use the Android release workflow with `build_release=true` and `publish_internal=true` for the fastest path to Internal Testing. Complete physical-device QA before production rollout.
