# SmartStudents V62 — Release Candidate Handoff

V62 is the release-candidate continuation of V61. No product feature changes were introduced.

## Release hardening
- Fixed the candidate verification step so manifest/AAB paths are resolved correctly after changing directories.
- Re-checks the exact AAB SHA-256 before Play publication.
- Copies the verified AAB to the Play upload artifact while preserving metadata.
- Makes the Play upload artifact read-only after verification.
- Confirms the upload artifact remains byte-for-byte identical to the manifest checksum.

## Status
Run the repository release gate, production preflight, and final smoke checks before GitHub Actions release execution.

## Release path
GitHub Actions -> signed AAB -> cryptographic verification -> Firebase (optional) -> Google Play Internal Testing -> physical QA -> Production.
