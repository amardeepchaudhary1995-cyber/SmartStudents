package com.smartstudents.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun AdminDashboardScreen(
    totalCourses: Int = 0,
    publishedCourses: Int = 0,
    pendingCourses: Int = 0,
    onManageCourses: () -> Unit = {}
) {
    Column(
        Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Admin Dashboard", style = MaterialTheme.typography.headlineSmall)
        Stat("Total Courses", totalCourses)
        Stat("Published", publishedCourses)
        Stat("Pending", pendingCourses)
        Button(
            onClick = onManageCourses,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Manage Courses")
        }
    }
}

@Composable
private fun Stat(label: String, value: Int) {
    Card(Modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth().padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label)
            Text(value.toString(), style = MaterialTheme.typography.titleLarge)
        }
    }
}
