package com.smartstudents.app.admin

data class CourseEditorState(
    val board: String = "",
    val className: String = "",
    val subject: String = "",
    val courseTitle: String = "",
    val chapterTitle: String = "",
    val videoUrl: String = "",
    val notesUrl: String = ""
)

class AdminCourseEditor {
    fun isValid(state: CourseEditorState): Boolean =
        state.board.isNotBlank() &&
        state.className.isNotBlank() &&
        state.subject.isNotBlank() &&
        state.courseTitle.trim().length >= 3 &&
        state.chapterTitle.trim().length >= 3
}
