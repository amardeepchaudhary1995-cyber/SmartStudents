package com.smartstudents.app.progress

data class LearningProgress(
    val studentId: String,
    val courseId: String,
    val completedLessons: Int = 0,
    val totalLessons: Int = 0,
    val bestQuizPercentage: Int = 0
) {
    val completionPercentage: Int
        get() = if (totalLessons == 0) 0
                else (completedLessons * 100) / totalLessons
}

class ProgressTracker {
    fun markLessonComplete(progress: LearningProgress): LearningProgress =
        progress.copy(
            completedLessons = minOf(progress.completedLessons + 1, progress.totalLessons)
        )
}
