package com.smartstudents.app.auth

class AuthRepository {
    fun normalizeEmail(email: String): String = email.trim().lowercase()

    fun validateEmail(email: String): Boolean {
        val value = normalizeEmail(email)
        return value.length <= 254 &&
            Regex("^[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Za-z0-9-]+(?:\\.[A-Za-z0-9-]+)+$").matches(value)
    }

    fun validatePassword(password: String): Boolean =
        password.length >= 6 && password.length <= 4096
}
