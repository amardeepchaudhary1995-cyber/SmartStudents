package com.smartstudents.app.content

data class CourseFilter(
    val className: String? = null,
    val board: String? = null,
    val subject: String? = null
)

object ContentFilters {
    fun matches(
        board: String,
        className: String,
        subject: String,
        filter: CourseFilter
    ): Boolean {
        return (filter.board == null || filter.board == board) &&
               (filter.className == null || filter.className == className) &&
               (filter.subject == null || filter.subject == subject)
    }
}
