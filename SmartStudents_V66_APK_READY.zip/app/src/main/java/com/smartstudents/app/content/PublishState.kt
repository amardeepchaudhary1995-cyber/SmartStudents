package com.smartstudents.app.content

data class PublishState(
    val courseId: String,
    val published: Boolean = false
)

object PublishValidator {
    fun canPublish(title: String, subject: String, className: String, board: String): Boolean =
        title.isNotBlank() &&
        subject.isNotBlank() &&
        className.isNotBlank() &&
        board.isNotBlank()
}
