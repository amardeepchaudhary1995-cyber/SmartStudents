package com.smartstudents.app.notifications

import android.app.NotificationManager
import android.app.NotificationChannel
import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import android.Manifest
import android.content.pm.PackageManager
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.smartstudents.app.MainActivity

class SmartStudentsMessagingService : FirebaseMessagingService() {
    override fun onNewToken(token: String) {
        NotificationRegistration.saveToken(applicationContext, token)
    }

    override fun onMessageReceived(message: RemoteMessage) {
        val title = message.notification?.title ?: message.data["title"] ?: "Smart Students"
        val body = message.notification?.body ?: message.data["body"] ?: ""
        NotificationHelper.show(applicationContext, title, body)
    }
}

object NotificationRegistration {
    private const val PREFS = "smart_students_notifications_v25"
    private const val TOKEN = "fcm_token"

    fun subscribe(context: android.content.Context) {
        val prefs = context.getSharedPreferences(PREFS, 0)
        val subscribedUid = prefs.getString("topic_uid", null)
        val uid = com.google.firebase.auth.FirebaseAuth.getInstance().currentUser?.uid ?: return
        val messaging = com.google.firebase.messaging.FirebaseMessaging.getInstance()

        // Avoid repeating the topic request and token fetch on every recomposition/app start.
        if (subscribedUid != uid) {
            messaging.subscribeToTopic("all_students")
                .addOnSuccessListener {
                    prefs.edit().putString("topic_uid", uid).apply()
                }
        }
        messaging.token.addOnSuccessListener { saveToken(context, it) }
    }

    fun clearSubscriptionState(context: android.content.Context) {
        context.getSharedPreferences(PREFS, 0).edit().remove("topic_uid").apply()
    }

    fun saveToken(context: android.content.Context, token: String) {
        context.getSharedPreferences(PREFS, 0).edit().putString(TOKEN, token).apply()
    }
}
