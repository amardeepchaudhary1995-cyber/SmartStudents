package com.smartstudents.app.quiz

data class QuizQuestion(
    val id: String,
    val text: String,
    val options: List<String>,
    val correctIndex: Int
)

data class QuizResult(
    val total: Int,
    val correct: Int
) {
    val percentage: Int
        get() = if (total == 0) 0 else (correct * 100) / total
}

class QuizEngine(private val questions: List<QuizQuestion>) {
    fun submit(answers: Map<String, Int>): QuizResult {
        val correct = questions.count { answers[it.id] == it.correctIndex }
        return QuizResult(questions.size, correct)
    }
}
