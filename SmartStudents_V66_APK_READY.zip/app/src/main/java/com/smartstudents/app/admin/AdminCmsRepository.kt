package com.smartstudents.app.admin

import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions

data class CmsCourse(val id:String="", val title:String="", val board:String="", val className:String="", val subject:String="", val published:Boolean=false)
data class CmsChapter(val id:String="", val title:String="", val order:Int=0)
data class CmsLesson(val id:String="", val title:String="", val description:String="", val videoUrl:String="", val notesUrl:String="", val order:Int=0)
data class CmsQuestion(val id:String="", val question:String="", val options:List<String> = emptyList(), val answerIndex:Int=0, val order:Int=0)

class AdminCmsRepository(private val db: FirebaseFirestore) {
    fun saveCourse(c:CmsCourse, done:(Boolean,String?)->Unit) {
        if(c.id.isBlank() || c.title.trim().length<3) { done(false,"Course ID और title जरूरी हैं"); return }
        db.collection("courses").document(c.id.trim()).set(c, SetOptions.merge())
            .addOnSuccessListener{done(true,null)}.addOnFailureListener{done(false,it.localizedMessage)}
    }
    fun deleteCourse(id:String, done:(Boolean,String?)->Unit) =
        db.collection("courses").document(id).delete().addOnSuccessListener{done(true,null)}
            .addOnFailureListener{done(false,it.localizedMessage)}

    fun saveChapter(courseId:String,c:CmsChapter,done:(Boolean,String?)->Unit) =
        db.collection("courses").document(courseId).collection("chapters").document(c.id)
            .set(c,SetOptions.merge()).addOnSuccessListener{done(true,null)}
            .addOnFailureListener{done(false,it.localizedMessage)}

    fun saveLesson(courseId:String,chapterId:String,l:CmsLesson,done:(Boolean,String?)->Unit) =
        db.collection("courses").document(courseId).collection("chapters").document(chapterId)
            .collection("lessons").document(l.id).set(l,SetOptions.merge())
            .addOnSuccessListener{done(true,null)}.addOnFailureListener{done(false,it.localizedMessage)}

    fun saveQuestion(courseId:String,chapterId:String,lessonId:String,q:CmsQuestion,done:(Boolean,String?)->Unit) =
        db.collection("courses").document(courseId).collection("chapters").document(chapterId)
            .collection("lessons").document(lessonId).collection("questions").document(q.id)
            .set(q,SetOptions.merge()).addOnSuccessListener{done(true,null)}
            .addOnFailureListener{done(false,it.localizedMessage)}

    fun deleteChapter(courseId:String,id:String,done:(Boolean,String?)->Unit) =
        db.collection("courses").document(courseId).collection("chapters").document(id).delete()
            .addOnSuccessListener{done(true,null)}.addOnFailureListener{done(false,it.localizedMessage)}

    fun deleteLesson(courseId:String,chapterId:String,id:String,done:(Boolean,String?)->Unit) =
        db.collection("courses").document(courseId).collection("chapters").document(chapterId)
            .collection("lessons").document(id).delete().addOnSuccessListener{done(true)}
            .addOnFailureListener{done(false,it.localizedMessage)}

    fun deleteQuestion(courseId:String,chapterId:String,lessonId:String,id:String,done:(Boolean,String?)->Unit) =
        db.collection("courses").document(courseId).collection("chapters").document(chapterId)
            .collection("lessons").document(lessonId).collection("questions").document(id).delete()
            .addOnSuccessListener{done(true)}.addOnFailureListener{done(false,it.localizedMessage)}
}
