package com.smartstudents.app.admin

object AdminPermissions {
    fun canManageContent(role: String): Boolean =
        role.uppercase() == "ADMIN"

    fun canViewParentData(role: String): Boolean =
        role.uppercase() == "PARENT" || role.uppercase() == "ADMIN"
}
