package com.smartstudents.app.admin

data class DashboardStats(
    val students: Int,
    val courses: Int,
    val chapters: Int,
    val quizzes: Int
)

object DemoAdminDashboard {
    val stats = DashboardStats(
        students = 0,
        courses = 1,
        chapters = 2,
        quizzes = 2
    )
}
