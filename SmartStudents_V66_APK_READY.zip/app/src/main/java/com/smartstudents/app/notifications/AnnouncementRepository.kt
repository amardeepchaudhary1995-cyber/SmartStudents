package com.smartstudents.app.notifications

import com.google.firebase.firestore.FirebaseFirestore

data class Announcement(val id:String="", val title:String="", val body:String="", val published:Boolean=true, val createdAt:Long=0L)

class AnnouncementRepository(private val db: FirebaseFirestore) {
    fun loadPublished(onResult:(List<Announcement>, String?)->Unit) {
        db.collection("announcements").whereEqualTo("published", true).get()
            .addOnSuccessListener { s ->
                val list=s.documents.map { d -> Announcement(d.id, d.getString("title")?:"", d.getString("body")?:"",
                    d.getBoolean("published")?:true, d.getLong("createdAt")?:0L) }
                    .sortedByDescending { it.createdAt }
                onResult(list,null)
            }.addOnFailureListener { onResult(emptyList(),it.localizedMessage) }
    }
    fun publish(title:String,body:String,onResult:(Boolean,String?)->Unit) {
        val data=mapOf("title" to title,"body" to body,"published" to true,"createdAt" to System.currentTimeMillis())
        db.collection("announcements").add(data).addOnSuccessListener{onResult(true,null)}
            .addOnFailureListener{onResult(false,it.localizedMessage)}
    }
}
