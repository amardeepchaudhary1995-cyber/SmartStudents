package com.smartstudents.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun ProfileSettingsScreen(
    name: String = "Student",
    email: String = "",
    role: String = "STUDENT",
    onLogout: () -> Unit = {},
    onNotifications: () -> Unit = {},
    onPrivacy: () -> Unit = {},
    onDeleteAccount: () -> Unit = {}
) {
    Column(
        Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Profile", style = MaterialTheme.typography.headlineSmall)
        Text(name, style = MaterialTheme.typography.titleLarge)
        Text(email)
        Text("Role: $role")
        Button(onClick = onNotifications, modifier = Modifier.fillMaxWidth()) {
            Text("Notifications")
        }
        OutlinedButton(onClick = onPrivacy, modifier = Modifier.fillMaxWidth()) {
            Text("Privacy & data")
        }
        OutlinedButton(onClick = onLogout, modifier = Modifier.fillMaxWidth()) {
            Text("Logout")
        }
        OutlinedButton(onClick = onDeleteAccount, modifier = Modifier.fillMaxWidth()) {
            Text("Delete account")
        }
    }
}
