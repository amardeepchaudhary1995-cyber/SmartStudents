package com.smartstudents.app.parent

import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.functions.FirebaseFunctions

class ParentRepository(
    private val db: FirebaseFirestore,
    private val functions: FirebaseFunctions = FirebaseFunctions.getInstance()
) {
    fun createStudentLinkCode(studentUid: String, onResult: (String?, String?) -> Unit) {
        functions.getHttpsCallable("createParentLinkCode").call()
            .addOnSuccessListener { result ->
                val code = (result.data as? Map<*, *>)?.get("code")?.toString()
                if (code.isNullOrBlank()) onResult(null, "Code was not returned.")
                else onResult(code, null)
            }
            .addOnFailureListener { onResult(null, it.localizedMessage) }
    }

    fun linkStudent(parentUid: String, code: String, onResult: (Boolean, String?) -> Unit) {
        functions.getHttpsCallable("linkParentToStudent")
            .call(mapOf("code" to code.trim().uppercase()))
            .addOnSuccessListener { onResult(true, null) }
            .addOnFailureListener { onResult(false, it.localizedMessage) }
    }

    fun loadChildren(parentUid: String, onResult: (List<String>, String?) -> Unit) {
        db.collection("users").document(parentUid).collection("children").get()
            .addOnSuccessListener {
                onResult(it.documents.mapNotNull { d -> d.getString("studentUid") }, null)
            }
            .addOnFailureListener { onResult(emptyList(), it.localizedMessage) }
    }
}
