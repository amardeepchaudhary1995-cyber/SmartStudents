package com.smartstudents.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun QuizResultScreen(
    score: Int,
    total: Int,
    onRetry: () -> Unit = {},
    onContinue: () -> Unit = {}
) {
    val percentage = if (total > 0) (score * 100) / total else 0
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Quiz Result", style = MaterialTheme.typography.headlineSmall)
        Text("$score / $total", style = MaterialTheme.typography.displaySmall)
        Text("Score: $percentage%")
        Button(onClick = onRetry) { Text("Retry Quiz") }
        Button(onClick = onContinue) { Text("Continue Learning") }
    }
}
