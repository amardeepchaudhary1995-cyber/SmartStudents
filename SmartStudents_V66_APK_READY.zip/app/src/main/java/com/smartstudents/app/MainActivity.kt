package com.smartstudents.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.net.ConnectivityManager
import android.net.Network
import android.os.Bundle
import android.os.SystemClock
import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import com.google.firebase.firestore.FirebaseFirestore
import com.smartstudents.app.content.FirestoreContentRepository
import com.smartstudents.app.content.FirestoreQuizRepository
import com.smartstudents.app.data.*
import com.smartstudents.app.admin.AdminCmsRepository
import com.smartstudents.app.admin.AdminCmsScreen
import com.smartstudents.app.firebase.FirebaseGateway
import com.smartstudents.app.firebase.FirebaseSecurity
import com.smartstudents.app.firebase.FirestoreProgress
import com.smartstudents.app.quiz.QuizEngine
import com.smartstudents.app.quiz.QuizQuestion
import com.smartstudents.app.ui.*
import com.smartstudents.app.parent.ParentRepository
import com.smartstudents.app.notifications.AnnouncementRepository
import com.smartstudents.app.notifications.NotificationRegistration
import com.smartstudents.app.analytics.AppTelemetry

class MainActivity : ComponentActivity() {
    private var networkCallback: ConnectivityManager.NetworkCallback? = null
    private lateinit var networkManager: ConnectivityManager
    private val syncGateway by lazy { FirebaseGateway(applicationContext) }
    private var lastNetworkFlushAtMs = 0L
    private val networkFlushCooldownMs = 30_000L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FirebaseSecurity.initialize(applicationContext)
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1001)
        }
        AppTelemetry.sessionStarted(applicationContext, syncGateway.currentUid())
        setContent { SmartStudentsApp(applicationContext) }
        networkManager = getSystemService(ConnectivityManager::class.java)
    }

    override fun onStart() {
        super.onStart()
        // Keep network observation active only while the app is visible.
        // This avoids a long-lived network callback while the app is in background.
        if (networkCallback == null) {
            val callback = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    // Network callbacks can fire repeatedly during Wi-Fi/mobile handoff.
                    // Avoid waking Firebase and the CPU for duplicate retries.
                    val now = SystemClock.elapsedRealtime()
                    if (now - lastNetworkFlushAtMs >= networkFlushCooldownMs) {
                        lastNetworkFlushAtMs = now
                        syncGateway.flushPendingProgress()
                    }
                }
            }
            networkCallback = callback
            runCatching { networkManager.registerDefaultNetworkCallback(callback) }
        }
    }

    override fun onStop() {
        networkCallback?.let { callback ->
            runCatching { networkManager.unregisterNetworkCallback(callback) }
        }
        networkCallback = null
        lastNetworkFlushAtMs = 0L
        super.onStop()
    }
}

private class AppStore(context: Context) {
    private val prefs = context.getSharedPreferences("smart_students_v20", Context.MODE_PRIVATE)
    private val local = LocalProgressStore(context)
    val firebase = FirebaseGateway(context)

    fun isLoggedIn(): Boolean {
        // Firebase is the source of truth when cloud mode is configured.
        // A stale local flag must never bypass authentication after a token
        // expires, the account is removed, or another user signs out.
        return if (firebase.isConfigured()) {
            firebase.currentUid() != null
        } else {
            prefs.getBoolean("logged_in", false)
        }
    }
    fun name() = prefs.getString("name", "Student") ?: "Student"
    fun email() = prefs.getString("email", "") ?: ""
    fun uid() = prefs.getString("uid", "") ?: ""

    fun login(name: String, email: String, uid: String = "") {
        prefs.edit().putBoolean("logged_in", true).putString("name", name)
            .putString("email", email).putString("uid", uid).apply()
    }
    fun logout() { firebase.signOut(); prefs.edit().clear().apply() }

    fun progress(courseId: String, total: Int) = local.get(courseId).copy(totalLessons = total)
    fun completed(courseId: String, lessonId: String) = local.isLessonCompleted(courseId, lessonId)

    fun complete(courseId: String, lessonId: String, total: Int): CourseProgress {
        val value = local.markLessonComplete(courseId, lessonId, total)
        firebase.syncProgress(FirestoreProgress(
            uid(), courseId, value.completedLessons, value.totalLessons, value.bestScore,
            local.completedLessonIds(courseId)
        ))
        return value
    }
    fun score(courseId: String, correct: Int, total: Int): CourseProgress {
        val value = local.saveQuizScore(courseId, correct, total)
        firebase.syncProgress(FirestoreProgress(
            uid(), courseId, value.completedLessons, value.totalLessons, value.bestScore,
            local.completedLessonIds(courseId)
        ))
        return value
    }
}

@Composable
fun SmartStudentsApp(context: Context) {
    val store = remember { AppStore(context) }
    LaunchedEffect(Unit) {
        store.firebase.flushPendingProgress()
        if (store.firebase.isConfigured() && store.firebase.currentUid() != null) {
            NotificationRegistration.subscribe(context)
        }
    }
    var loggedIn by remember { mutableStateOf(store.isLoggedIn() || store.firebase.currentUid() != null) }
    val nav = rememberNavController()

    DisposableEffect(store.firebase.isConfigured()) {
        if (!store.firebase.isConfigured()) return@DisposableEffect onDispose { }
        val listener = FirebaseAuth.AuthStateListener { auth ->
            if (auth.currentUser == null) {
                loggedIn = false
            }
        }
        store.firebase.addAuthStateListener(listener)
        onDispose { store.firebase.removeAuthStateListener(listener) }
    }

    MaterialTheme {
        if (!loggedIn) {
            LoginScreen(
                firebaseEnabled = store.firebase.isConfigured(),
                onLogin = { name, email, password, done ->
                    if (store.firebase.isConfigured()) {
                        store.firebase.signInOrCreate(name, email, password) { success, uid, message ->
                            if (success) {
                                NotificationRegistration.subscribe(context)
                                store.login(name, email, uid ?: "")
                                AppTelemetry.login(context, true)
                                loggedIn = true
                                nav.navigate(ScreenRoutes.HOME) { popUpTo(0) }
                                done(true, null)
                            } else {
                                AppTelemetry.login(context, false)
                                done(false, message ?: "Login failed. Please try again.")
                            }
                        }
                    } else {
                        store.login(name, email)
                        AppTelemetry.login(context, true)
                        loggedIn = true
                        nav.navigate(ScreenRoutes.HOME) { popUpTo(0) }
                        done(true, null)
                    }
                }
            )
        } else {
            NavHost(nav, ScreenRoutes.HOME) {
                composable(ScreenRoutes.HOME) {
                    DashboardHome(store.name(), store.progress("math-cbse-10", 6),
                        { nav.navigate(ScreenRoutes.COURSES) },
                        { nav.navigate(ScreenRoutes.PROGRESS) },
                        { nav.navigate(ScreenRoutes.PROFILE) },
                        { nav.navigate("admin") },
                        { nav.navigate("announcements") },
                        { nav.navigate("parentLink") })
                }
                composable(ScreenRoutes.COURSES) {
                    CloudCourseBrowserScreen(store.firebase) { c -> nav.navigate("course/${c.id}") }
                }
                composable("course/{id}", arguments=listOf(navArgument("id"){type=NavType.StringType})) { b ->
                    val id=b.arguments?.getString("id") ?: ""
                    CloudCourseDetailScreen(store.firebase,id) { lesson ->
                        AppTelemetry.courseOpened(context, id)
                        nav.navigate("lesson/${id}/${lesson.chapterId}/${lesson.id}")
                    }
                }
                composable("lesson/{course}/{chapter}/{lesson}", arguments=listOf(
                    navArgument("course"){type=NavType.StringType},
                    navArgument("chapter"){type=NavType.StringType},
                    navArgument("lesson"){type=NavType.StringType}
                )) { b ->
                    val courseId=b.arguments?.getString("course") ?: ""
                    val chapterId=b.arguments?.getString("chapter") ?: ""
                    val lessonId=b.arguments?.getString("lesson") ?: ""
                    AppTelemetry.lessonOpened(context, courseId, lessonId)
                    LessonLoaderScreen(store, courseId, chapterId, lessonId,
                        onQuiz={ nav.navigate("quiz/$courseId/$chapterId/$lessonId") },
                        onBack={nav.popBackStack()})
                }
                composable("quiz/{course}/{chapter}/{lesson}", arguments=listOf(
                    navArgument("course"){type=NavType.StringType},
                    navArgument("chapter"){type=NavType.StringType},
                    navArgument("lesson"){type=NavType.StringType}
                )) { b ->
                    QuizLoaderScreen(
                        store, b.arguments?.getString("course") ?: "",
                        b.arguments?.getString("chapter") ?: "",
                        b.arguments?.getString("lesson") ?: "",
                        onDone={ correct,total ->
                            val courseId=b.arguments?.getString("course") ?: ""
                            store.score(courseId,correct,total)
                            AppTelemetry.quizCompleted(context, courseId, correct, total)
                            nav.navigate("result/$correct/$total")
                        }, onBack={nav.popBackStack()})
                }
                composable("result/{correct}/{total}", arguments=listOf(
                    navArgument("correct"){type=NavType.IntType},navArgument("total"){type=NavType.IntType}
                )) { b ->
                    QuizResultScreen(b.arguments?.getInt("correct")?:0,b.arguments?.getInt("total")?:0,
                        {nav.popBackStack()}, {nav.navigate(ScreenRoutes.PROGRESS)})
                }
                composable(ScreenRoutes.PROGRESS) { ProgressDashboardScreen(listOf(store.progress("math-cbse-10",6))) }
                composable("announcements") {
                    if (store.firebase.isConfigured()) AnnouncementsScreen(AnnouncementRepository(FirebaseFirestore.getInstance()), context, { nav.popBackStack() })
                    else Text("Announcements require Firebase.", Modifier.padding(20.dp))
                }
                composable("parentLink") {
                    if (store.firebase.isConfigured()) ParentLinkScreen(ParentRepository(FirebaseFirestore.getInstance()), store.uid(), { nav.popBackStack() })
                    else Text("Parent linking requires Firebase.", Modifier.padding(20.dp))
                }
                composable("adminAnnouncements") {
                    if (store.firebase.isConfigured()) AdminAnnouncementsScreen(AnnouncementRepository(FirebaseFirestore.getInstance()), { nav.popBackStack() })
                    else Text("Announcements require Firebase.", Modifier.padding(20.dp))
                }
                composable("admin") {
                    AdminCmsScreen(
                        store.firebase.isConfigured(),
                        if (store.firebase.isConfigured()) AdminCmsRepository(FirebaseFirestore.getInstance()) else null,
                        if (store.firebase.isConfigured()) FirebaseStorageRepository(com.google.firebase.storage.FirebaseStorage.getInstance()) else null,
                        { nav.popBackStack() }
                    )
                }
                composable(ScreenRoutes.PROFILE) {
                    var showDeleteDialog by remember { mutableStateOf(false) }
                    var showPrivacyDialog by remember { mutableStateOf(false) }
                    var deleteMessage by remember { mutableStateOf<String?>(null) }
                    ProfileSettingsScreen(
                        store.name(), store.email(),
                        onLogout={store.logout();loggedIn=false},
                        onPrivacy={showPrivacyDialog=true},
                        onDeleteAccount={showDeleteDialog=true}
                    )
                    if (showPrivacyDialog) {
                        AlertDialog(
                            onDismissRequest={showPrivacyDialog=false},
                            title={Text("Privacy & data")},
                            text={Text("Smart Students uses your account information to sign you in and sync learning progress when Firebase cloud mode is enabled. Learning progress and parent-link data are stored for your account. Notifications are optional. Analytics and crash reporting may be enabled in the production Firebase project. You can delete your account from Profile; deletion removes your Firebase account and user-owned data handled by the app.")},
                            confirmButton={
                                Button(onClick={showPrivacyDialog=false}) { Text("OK") }
                            }
                        )
                    }
                    if (showDeleteDialog) {
                        AlertDialog(
                            onDismissRequest={ if (deleteMessage == null) showDeleteDialog=false },
                            title={Text("Delete account?")},
                            text={Text(deleteMessage ?: "This permanently removes your Smart Students Firebase account and user-owned progress/link data. This cannot be undone.")},
                            confirmButton={
                                Button(enabled=deleteMessage == null, onClick={
                                    store.firebase.deleteAccount { ok, msg ->
                                        if (ok) { showDeleteDialog=false; loggedIn=false; nav.navigate(ScreenRoutes.HOME) { popUpTo(0) } }
                                        else deleteMessage=msg ?: "Account deletion failed."
                                    }
                                }) { Text("Delete permanently") }
                            },
                            dismissButton={
                                OutlinedButton(onClick={showDeleteDialog=false}) { Text("Cancel") }
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LoginScreen(
    firebaseEnabled: Boolean,
    onLogin: (String, String, String, (Boolean, String?) -> Unit) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var showPassword by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("🎓 Smart Students", style = MaterialTheme.typography.headlineMedium)
        Text(if (firebaseEnabled) "Cloud login enabled" else "Offline demo mode")

        OutlinedTextField(
            value = name,
            onValueChange = { name = it; error = "" },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Name") },
            singleLine = true,
            enabled = !busy
        )
        OutlinedTextField(
            value = email,
            onValueChange = { email = it; error = "" },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Email") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
            enabled = !busy
        )
        OutlinedTextField(
            value = password,
            onValueChange = { password = it; error = "" },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Password (6+ chars)") },
            singleLine = true,
            visualTransformation = if (showPassword) androidx.compose.ui.text.input.VisualTransformation.None
            else PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            trailingIcon = {
                TextButton(onClick = { showPassword = !showPassword }, enabled = !busy) {
                    Text(if (showPassword) "Hide" else "Show")
                }
            },
            enabled = !busy
        )

        if (error.isNotEmpty()) {
            Text(error, color = MaterialTheme.colorScheme.error)
        }

        Button(
            enabled = !busy,
            onClick = {
                val cleanName = name.trim()
                val cleanEmail = email.trim().lowercase()
                val validName = cleanName.length >= 2
                val validEmail = android.util.Patterns.EMAIL_ADDRESS.matcher(cleanEmail).matches()
                val validPassword = password.length >= 6

                error = when {
                    !validName -> "Name कम से कम 2 characters का होना चाहिए."
                    !validEmail -> "Valid email डालें."
                    !validPassword -> "Password कम से कम 6 characters का होना चाहिए."
                    else -> ""
                }

                if (error.isEmpty()) {
                    busy = true
                    onLogin(cleanName, cleanEmail, password) { success, message ->
                        busy = false
                        if (!success) error = message ?: "Login failed. Please try again."
                    }
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            if (busy) {
                CircularProgressIndicator(
                    modifier = Modifier.size(18.dp),
                    strokeWidth = 2.dp
                )
                Spacer(Modifier.width(8.dp))
                Text("Please wait…")
            } else {
                Text("Login / Continue")
            }
        }
    }
}

@Composable
private fun CloudCourseBrowserScreen(firebase:FirebaseGateway,onCourseClick:(CatalogItem)->Unit) {
    var courses by remember{mutableStateOf(SmartStudentsCatalog.demoCourses)}
    var loading by remember{mutableStateOf(firebase.isConfigured())}
    var message by remember{mutableStateOf("")}
    LaunchedEffect(firebase.isConfigured()) {
        if(firebase.isConfigured()) FirestoreContentRepository(FirebaseFirestore.getInstance()).loadPublishedCourses{cloud,error->
            if(cloud.isNotEmpty()) courses=cloud
            message=if(error!=null)"Cloud unavailable — demo courses shown." else "Published courses from cloud"
            loading=false
        } else loading=false
    }
    Column(Modifier.fillMaxSize()) {
        if(loading)LinearProgressIndicator(Modifier.fillMaxWidth())
        if(message.isNotEmpty())Text(message,Modifier.padding(16.dp))
        CourseBrowserScreen(courses,onCourseClick)
    }
}

@Composable
private fun CloudCourseDetailScreen(firebase:FirebaseGateway,courseId:String,onLesson:(LessonItem)->Unit) {
    var course by remember(courseId){mutableStateOf<CourseDetail?>(null)}
    var loading by remember(courseId){mutableStateOf(firebase.isConfigured())}
    LaunchedEffect(courseId) {
        if(firebase.isConfigured()) FirestoreContentRepository(FirebaseFirestore.getInstance()).loadCourseDetail(courseId){v,_->course=v;loading=false}
        else {course=DemoLearningFlow.course.takeIf{it.id==courseId}?:DemoLearningFlow.course;loading=false}
    }
    if(loading)Column(Modifier.fillMaxSize().padding(20.dp)){LinearProgressIndicator(Modifier.fillMaxWidth());Text("Loading course…")}
    else if(course!=null)CourseDetailScreen(course!!,onLesson)
    else Text("Course content unavailable.",Modifier.padding(20.dp))
}

@Composable
private fun LessonLoaderScreen(store:AppStore,courseId:String,chapterId:String,lessonId:String,onQuiz:()->Unit,onBack:()->Unit) {
    var lesson by remember{mutableStateOf<LessonItem?>(null)}
    var loading by remember{mutableStateOf(true)}
    LaunchedEffect(courseId,chapterId,lessonId) {
        if(store.firebase.isConfigured()) FirestoreContentRepository(FirebaseFirestore.getInstance()).loadCourseDetail(courseId){course,_->
            lesson=course?.chapters?.flatMap{it.lessons}?.firstOrNull{it.id==lessonId}; loading=false
        } else {
            lesson=DemoLearningFlow.course.chapters.flatMap{it.lessons}.firstOrNull{it.id==lessonId}; loading=false
        }
    }
    if(loading)Text("Loading lesson…",Modifier.padding(20.dp))
    else lesson?.let { l ->
        val context=LocalContext.current
        val total=DemoLearningFlow.course.chapters.sumOf{it.lessons.size}.takeIf{courseId=="math-cbse-10"} ?: 1
        val done=store.completed(courseId,l.id)
        LessonScreenV20(l,done,{store.complete(courseId,l.id,total); AppTelemetry.lessonCompleted(context, courseId, l.id)},onQuiz,onBack,
            {url->openUrl(context,url)})
    } ?: Text("Lesson not found.",Modifier.padding(20.dp))
}

private fun openUrl(context:Context,url:String) {
    if(url.isBlank())return
    runCatching{context.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(url)))}
}

@Composable
private fun QuizLoaderScreen(store:AppStore,courseId:String,chapterId:String,lessonId:String,onDone:(Int,Int)->Unit,onBack:()->Unit) {
    var questions by remember{mutableStateOf<List<QuizQuestion>>(emptyList())}
    var loading by remember{mutableStateOf(store.firebase.isConfigured())}
    LaunchedEffect(courseId,chapterId,lessonId) {
        if(store.firebase.isConfigured()) FirestoreQuizRepository(FirebaseFirestore.getInstance()).loadQuestions(courseId,chapterId,lessonId){q,_->
            questions=q;loading=false
        } else {questions=listOf(
            QuizQuestion("q1","2 + 2 = ?",listOf("3","4","5","6"),1),
            QuizQuestion("q2","Half of 10 is?",listOf("2","5","8","10"),1));loading=false}
    }
    when {
        loading->Text("Loading quiz…",Modifier.padding(20.dp))
        questions.isEmpty()->Column(Modifier.padding(20.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
            Text("No quiz questions yet.",style=MaterialTheme.typography.titleLarge)
            Text("Admin can add questions under this lesson in Firestore.")
            OutlinedButton(onClick=onBack){Text("Back")}
        }
        else->QuizScreenV20(questions,onDone)
    }
}

@Composable
private fun QuizScreenV20(questions:List<QuizQuestion>,onDone:(Int,Int)->Unit) {
    var index by remember{mutableIntStateOf(0)}; var correct by remember{mutableIntStateOf(0)}; var selected by remember{mutableStateOf<Int?>(null)}
    val q=questions[index]
    Column(Modifier.fillMaxSize().padding(20.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        Text("Quiz • ${index+1}/${questions.size}",style=MaterialTheme.typography.titleLarge)
        Text(q.text,style=MaterialTheme.typography.headlineSmall)
        q.options.forEachIndexed{i,o->OutlinedButton(onClick={selected=i},Modifier.fillMaxWidth()){Text(o)}}
        selected?.let{a->Text(if(a==q.correctIndex)"🎉 Correct!" else "❌ Incorrect")
            Button(onClick={
                val nextCorrect=correct+if(a==q.correctIndex)1 else 0
                if(index==questions.lastIndex)onDone(nextCorrect,questions.size) else {correct=nextCorrect;index++;selected=null}
            },Modifier.fillMaxWidth()){Text(if(index==questions.lastIndex)"Finish Quiz" else "Next")}}
    }
}

@Composable
private fun DashboardHome(name:String,progress:CourseProgress,onCourses:()->Unit,onProgress:()->Unit,onProfile:()->Unit,onAdmin:()->Unit,onAnnouncements:()->Unit,onParentLink:()->Unit){
    Scaffold(topBar={TopAppBar(title={Text("Smart Students")})}){p->LazyColumn(Modifier.padding(p).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        item{Text("Hello, $name 👋",style=MaterialTheme.typography.headlineSmall)}
        item{HomeCard("📚 My Courses","Continue learning",onCourses)}
        item{HomeCard("📊 My Progress","${progress.completedLessons}/${progress.totalLessons} lessons • Best ${progress.bestScore}%",onProgress)}
        item{HomeCard("👤 Profile","Account settings",onProfile)}
        item{HomeCard("📢 Announcements","School updates and notices",onAnnouncements)}
        item{HomeCard("👨‍👩‍👧 Parent Link","Generate a one-time parent link code",onParentLink)}
        item{HomeCard("🛠 Admin CMS","Manage learning content",onAdmin)}
    }}
}
@Composable private fun HomeCard(title:String,subtitle:String,action:()->Unit){Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){Text(title,style=MaterialTheme.typography.titleLarge);Text(subtitle);Button(onClick=action){Text("Open")}}}}

@Composable
private fun LessonScreenV20(lesson:LessonItem,alreadyCompleted:Boolean,onComplete:()->Unit,onQuiz:()->Unit,onBack:()->Unit,onOpenUrl:(String)->Unit){
    var completed by remember(lesson.id,alreadyCompleted){mutableStateOf(alreadyCompleted)}
    Column(Modifier.fillMaxSize().padding(20.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        Text(lesson.title,style=MaterialTheme.typography.headlineSmall)
        Text(lesson.description.ifBlank{"Learn this lesson step by step."})
        if(lesson.videoUrl.isNotBlank())Button(onClick={onOpenUrl(lesson.videoUrl)},Modifier.fillMaxWidth()){Text("▶ Watch Video")}
        else Text("🎥 Video not added yet")
        if(lesson.notesUrl.isNotBlank())OutlinedButton(onClick={onOpenUrl(lesson.notesUrl)},Modifier.fillMaxWidth()){Text("📄 Open Notes / PDF")}
        else Text("📄 Notes/PDF not added yet")
        Button(onClick={onComplete;completed=true},Modifier.fillMaxWidth(),enabled=!completed){Text(if(completed)"✓ Lesson Completed" else "Mark Lesson Complete")}
        Button(onClick=onQuiz,Modifier.fillMaxWidth()){Text("📝 Start Quiz")}
        OutlinedButton(onClick=onBack,Modifier.fillMaxWidth()){Text("Back to Course")}
    }
}
