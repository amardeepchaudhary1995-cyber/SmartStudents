package com.smartstudents.app.content

import com.google.firebase.firestore.FirebaseFirestore
import com.smartstudents.app.quiz.QuizQuestion

class FirestoreQuizRepository(private val db: FirebaseFirestore) {
    fun loadQuestions(courseId: String, chapterId: String, lessonId: String,
                      onResult: (List<QuizQuestion>, Exception?) -> Unit) {
        db.collection("courses").document(courseId)
            .collection("chapters").document(chapterId)
            .collection("lessons").document(lessonId)
            .collection("questions").orderBy("order")
            .get()
            .addOnSuccessListener { snap ->
                val questions = snap.documents.mapNotNull { d ->
                    val options = (d.get("options") as? List<*>)?.mapNotNull { it?.toString() } ?: emptyList()
                    val answer = (d.getLong("answerIndex") ?: -1L).toInt()
                    val text = d.getString("question") ?: d.getString("text") ?: ""
                    if (text.isBlank() || options.size < 2 || answer !in options.indices) null
                    else QuizQuestion(d.id, text, options, answer)
                }
                onResult(questions, null)
            }
            .addOnFailureListener { onResult(emptyList(), it) }
    }
}
