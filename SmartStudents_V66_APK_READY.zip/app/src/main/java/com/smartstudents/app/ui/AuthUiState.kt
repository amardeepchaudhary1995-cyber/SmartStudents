package com.smartstudents.app.ui

data class LoginUiState(
    val email: String = "",
    val password: String = "",
    val loading: Boolean = false,
    val error: String? = null
)

data class RegisterUiState(
    val name: String = "",
    val email: String = "",
    val password: String = "",
    val role: String = "STUDENT",
    val loading: Boolean = false,
    val error: String? = null
)
