package com.smartstudents.app.ui

object ScreenRoutes {
    const val HOME = "home"
    const val LOGIN = "login"
    const val REGISTER = "register"
    const val COURSES = "courses"
    const val PROGRESS = "progress"
    const val PROFILE = "profile"
    const val ADMIN = "admin"
}
