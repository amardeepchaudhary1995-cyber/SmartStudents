package com.smartstudents.app.admin

enum class ContentAction { ADD, EDIT, DELETE }

data class ContentItem(
    val id: String,
    val title: String,
    val type: String
)

object AdminActions {
    fun validateTitle(title: String): Boolean = title.trim().length >= 3
}
