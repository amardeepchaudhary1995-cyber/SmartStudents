package com.smartstudents.app.parent

data class ChildSummary(
    val name: String,
    val className: String,
    val board: String,
    val courseCompletion: Int,
    val latestQuizScore: Int
)

data class ParentDashboardState(
    val children: List<ChildSummary> = emptyList()
)
