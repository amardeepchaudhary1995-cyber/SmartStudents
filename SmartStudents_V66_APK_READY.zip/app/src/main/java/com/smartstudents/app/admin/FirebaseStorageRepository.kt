package com.smartstudents.app.admin

import android.net.Uri
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageMetadata

class FirebaseStorageRepository(private val storage: FirebaseStorage) {
    fun uploadMedia(
        uri: Uri,
        courseId: String,
        chapterId: String,
        lessonId: String,
        kind: String,
        done: (Boolean, String?, String?) -> Unit
    ) {
        if (courseId.isBlank() || chapterId.isBlank() || lessonId.isBlank()) {
            done(false, null, "Course, Chapter और Lesson ID जरूरी हैं")
            return
        }
        val safeKind = if (kind == "video") "videos" else "notes"
        val ext = when (kind) {
            "video" -> "mp4"
            "notes" -> "pdf"
            else -> "bin"
        }
        val path = "courses/$courseId/chapters/$chapterId/lessons/$lessonId/$safeKind/${System.currentTimeMillis()}.$ext"
        val ref = storage.reference.child(path)
        val metadata = StorageMetadata.Builder()
            .setContentType(if (kind == "video") "video/mp4" else "application/pdf")
            .build()
        ref.putFile(uri, metadata)
            .addOnSuccessListener {
                ref.downloadUrl
                    .addOnSuccessListener { url -> done(true, url.toString(), null) }
                    .addOnFailureListener { e -> done(false, null, e.localizedMessage) }
            }
            .addOnFailureListener { e -> done(false, null, e.localizedMessage) }
    }
}
