package com.smartstudents.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class DashboardCard(
    val title: String,
    val value: String,
    val action: String
)

@Composable
fun StudentDashboardScreen(
    studentName: String = "Student",
    cards: List<DashboardCard> = listOf(
        DashboardCard("My Courses", "0", "Open"),
        DashboardCard("Lessons Done", "0", "Continue"),
        DashboardCard("Best Score", "0%", "Practice"),
        DashboardCard("Notifications", "0", "View")
    ),
    onAction: (DashboardCard) -> Unit = {}
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Hello, $studentName 👋", style = MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.height(4.dp))
            Text("Learn every day with Smart Students.")
        }
        items(cards.size) { index ->
            val card = cards[index]
            Card(Modifier.fillMaxWidth()) {
                Row(
                    Modifier.fillMaxWidth().padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(card.title, style = MaterialTheme.typography.titleMedium)
                        Text(card.value, style = MaterialTheme.typography.headlineMedium)
                    }
                    Button(onClick = { onAction(card) }) {
                        Text(card.action)
                    }
                }
            }
        }
    }
}
