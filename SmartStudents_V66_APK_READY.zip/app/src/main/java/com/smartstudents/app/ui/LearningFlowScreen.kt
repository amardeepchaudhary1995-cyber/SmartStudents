package com.smartstudents.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun CourseDetailScreen(
    course: CourseDetail = DemoLearningFlow.course,
    onLessonClick: (LessonItem) -> Unit = {}
) {
    Column(
        Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(course.title, style = MaterialTheme.typography.headlineSmall)
        Text("${course.board} • ${course.className} • ${course.subject}")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(course.chapters) { chapter ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(chapter.title, style = MaterialTheme.typography.titleMedium)
                        chapter.lessons.forEach { lesson ->
                            Button(
                                onClick = { onLessonClick(lesson) },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(lesson.title)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LessonScreen(
    lesson: LessonItem,
    onStartQuiz: () -> Unit = {},
    onBack: () -> Unit = {}
) {
    Column(
        Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(lesson.title, style = MaterialTheme.typography.headlineSmall)
        Text(lesson.description.ifBlank { "Learn this lesson step by step." })
        Text("Video: ${if (lesson.videoUrl.isBlank()) "Coming soon" else lesson.videoUrl}")
        Text("Notes: ${if (lesson.notesUrl.isBlank()) "Coming soon" else lesson.notesUrl}")
        Button(onClick = onStartQuiz, modifier = Modifier.fillMaxWidth()) {
            Text("Start Quiz")
        }
        Button(onClick = onBack, modifier = Modifier.fillMaxWidth()) {
            Text("Back to Course")
        }
    }
}
