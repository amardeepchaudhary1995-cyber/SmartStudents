package com.smartstudents.app.data

object DemoRepository {
    val courses = listOf(
        Course(
            id = "cbse-5-math",
            board = "CBSE",
            className = "Class 5",
            subject = "Mathematics",
            title = "Class 5 Mathematics",
            chapters = listOf(
                Chapter(
                    id = "ch1",
                    title = "Numbers and Operations",
                    quiz = listOf(
                        Question("2 + 2 = ?", listOf("3", "4", "5", "6"), 1)
                    )
                ),
                Chapter(
                    id = "ch2",
                    title = "Fractions",
                    quiz = listOf(
                        Question("Half of 10 is?", listOf("2", "5", "8", "10"), 1)
                    )
                )
            )
        )
    )
}
