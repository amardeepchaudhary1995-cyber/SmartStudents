package com.smartstudents.app.search

data class SearchableCourse(
    val id: String,
    val title: String,
    val board: String,
    val className: String,
    val subject: String
)

class CourseSearch {
    fun search(courses: List<SearchableCourse>, query: String): List<SearchableCourse> {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return courses
        return courses.filter {
            listOf(it.title, it.board, it.className, it.subject)
                .any { value -> value.lowercase().contains(q) }
        }
    }
}
