package com.smartstudents.app.notifications

enum class NotificationType { NEW_COURSE, TEST, RESULT, ANNOUNCEMENT }

data class AppNotification(
    val id: String,
    val title: String,
    val message: String,
    val type: NotificationType,
    val read: Boolean = false
)
