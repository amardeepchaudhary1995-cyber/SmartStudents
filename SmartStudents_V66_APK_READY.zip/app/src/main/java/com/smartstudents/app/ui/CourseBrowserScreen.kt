package com.smartstudents.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.smartstudents.app.data.CatalogItem
import com.smartstudents.app.data.SmartStudentsCatalog

@Composable
fun CourseBrowserScreen(
    courses: List<CatalogItem> = SmartStudentsCatalog.demoCourses,
    onCourseClick: (CatalogItem) -> Unit = {}
) {
    var query by remember { mutableStateOf("") }
    val filtered = remember(query, courses) {
        val q = query.trim().lowercase()
        if (q.isEmpty()) courses else courses.filter {
            listOf(it.title, it.board, it.className, it.subject)
                .any { value -> value.lowercase().contains(q) }
        }
    }

    Column(
        Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Find your course")
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Search class, board or subject") },
            singleLine = true
        )
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(filtered) { course ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    onClick = { onCourseClick(course) }
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text(course.title)
                        Text("${course.board} • ${course.className} • ${course.subject}")
                    }
                }
            }
        }
    }
}
