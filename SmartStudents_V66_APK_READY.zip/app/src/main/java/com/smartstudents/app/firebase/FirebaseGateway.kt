package com.smartstudents.app.firebase

import android.content.Context
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuth.AuthStateListener
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.functions.FirebaseFunctions
import org.json.JSONArray
import org.json.JSONObject
import com.smartstudents.app.analytics.AppTelemetry

/**
 * Firebase gateway with an offline-first progress queue.
 * Progress is submitted through a callable Cloud Function so clients cannot
 * directly invent lesson counts/scores.
 */
class FirebaseGateway(context: Context) {
    private val appContext = context.applicationContext
    private val configured = FirebaseApp.getApps(appContext).isNotEmpty()
    private val auth: FirebaseAuth? = if (configured) FirebaseAuth.getInstance() else null
    private val db: FirebaseFirestore? = if (configured) FirebaseFirestore.getInstance() else null
    private val functions: FirebaseFunctions? = if (configured) FirebaseFunctions.getInstance() else null
    private val queuePrefs = appContext.getSharedPreferences("smart_students_sync_queue_v24", Context.MODE_PRIVATE)

    fun isConfigured(): Boolean = configured
    fun currentUid(): String? = auth?.currentUser?.uid

    /** Observe Firebase session changes so the UI cannot remain on a protected
     * screen after token expiry, account removal, or sign-out elsewhere. */
    fun addAuthStateListener(listener: AuthStateListener) {
        auth?.addAuthStateListener(listener)
    }

    fun removeAuthStateListener(listener: AuthStateListener) {
        auth?.removeAuthStateListener(listener)
    }

    fun signInOrCreate(name: String, email: String, password: String,
        onResult: (success: Boolean, uid: String?, message: String?) -> Unit) {
        val a = auth ?: run {
            onResult(false, null, "Firebase configured नहीं है; local mode जारी रखें।"); return
        }
        a.signInWithEmailAndPassword(email, password).addOnCompleteListener { signIn ->
            if (signIn.isSuccessful) saveUser(a.currentUser?.uid, name, email, onResult)
            else a.createUserWithEmailAndPassword(email, password).addOnCompleteListener { create ->
                if (create.isSuccessful) saveUser(a.currentUser?.uid, name, email, onResult)
                else onResult(false, null, create.exception?.localizedMessage ?: "Login failed")
            }
        }
    }

    private fun saveUser(uid: String?, name: String, email: String,
        onResult: (Boolean, String?, String?) -> Unit) {
        if (uid == null || db == null) { onResult(false, null, "Firebase user unavailable"); return }
        val user = FirestoreUser(uid = uid, name = name, email = email)
        // Merge profile fields so server-owned fields such as parentUid,
        // role/admin claims mirrored in Firestore, and other user-owned data
        // are never accidentally erased on a normal login.
        val data = mapOf(
            "uid" to uid,
            "name" to name,
            "email" to email,
            "lastLoginAt" to com.google.firebase.firestore.FieldValue.serverTimestamp()
        )
        db.collection("users").document(uid).set(data, com.google.firebase.firestore.SetOptions.merge())
            .addOnSuccessListener { onResult(true, uid, null) }
            .addOnFailureListener { onResult(false, null, it.localizedMessage) }
    }

    fun syncProgress(progress: FirestoreProgress) {
        if (!configured || progress.uid.isBlank() || progress.courseId.isBlank()) return
        queue(progress)
        submit(progress)
    }

    private fun queue(progress: FirestoreProgress) {
        // Scope queued work to the authenticated account. This prevents a
        // later login from accidentally uploading a previous user's offline
        // progress under the new account.
        val key = "${progress.uid}::${progress.courseId}"
        queuePrefs.edit().putString(key, JSONObject().apply {
            put("uid", progress.uid); put("courseId", progress.courseId)
            put("bestQuizPercentage", progress.bestQuizPercentage)
            put("completedLessonIds", JSONArray(progress.completedLessonIds))
        }.toString()).apply()
    }

    private fun removeFromQueue(uid: String, courseId: String) =
        queuePrefs.edit().remove("$uid::$courseId").apply()

    private fun submit(progress: FirestoreProgress) {
        val f = functions ?: return
        val data = hashMapOf(
            "courseId" to progress.courseId,
            "completedLessonIds" to progress.completedLessonIds,
            "bestQuizPercentage" to progress.bestQuizPercentage
        )
        f.getHttpsCallable("submitProgress").call(data)
            .addOnSuccessListener { removeFromQueue(progress.uid, progress.courseId) }
            .addOnFailureListener { AppTelemetry.syncFailed(appContext, progress.courseId, it.localizedMessage) /* kept in queue for retry */ }
    }

    /** Retry all progress writes after login/app restart/network recovery. */
    fun flushPendingProgress() {
        val uid = currentUid() ?: return
        if (!configured || uid.isBlank()) return
        queuePrefs.all.forEach { (key, raw) ->
            if (!key.startsWith("$uid::")) return@forEach
            runCatching {
                val o = JSONObject(raw.toString())
                val ids = mutableListOf<String>()
                val arr = o.optJSONArray("completedLessonIds")
                if (arr != null) for (i in 0 until arr.length()) ids += arr.getString(i)
                submit(FirestoreProgress(
                    uid = currentUid() ?: o.optString("uid"),
                    courseId = o.optString("courseId").ifBlank {
                        key.removePrefix("$uid::")
                    },
                    bestQuizPercentage = o.optInt("bestQuizPercentage", 0),
                    completedLessonIds = ids
                ))
            }
        }
    }

    /** Permanently deletes the signed-in Firebase account and its user-owned data. */
    fun deleteAccount(onResult: (Boolean, String?) -> Unit) {
        val f = functions ?: run { onResult(false, "Firebase is not configured."); return }
        if (auth?.currentUser == null) { onResult(false, "No signed-in Firebase account."); return }
        f.getHttpsCallable("deleteMyAccount").call()
            .addOnSuccessListener {
                queuePrefs.edit().clear().apply()
                auth.signOut()
                onResult(true, null)
            }
            .addOnFailureListener { onResult(false, it.localizedMessage ?: "Account deletion failed.") }
    }

    fun signOut() {
        // Pending progress belongs to the signed-in account. Clear it on
        // logout so another account can never inherit or upload it.
        queuePrefs.edit().clear().apply()
        runCatching {
            com.google.firebase.messaging.FirebaseMessaging.getInstance().unsubscribeFromTopic("all_students")
        }
        runCatching {
            com.smartstudents.app.notifications.NotificationRegistration.clearSubscriptionState(appContext)
        }
        auth?.signOut()
    }
}
