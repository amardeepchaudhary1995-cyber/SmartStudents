package com.smartstudents.app.data

data class Course(
    val id: String,
    val board: String,
    val className: String,
    val subject: String,
    val title: String,
    val chapters: List<Chapter>
)

data class Chapter(
    val id: String,
    val title: String,
    val videoUrl: String? = null,
    val notesUrl: String? = null,
    val quiz: List<Question> = emptyList()
)

data class Question(
    val question: String,
    val options: List<String>,
    val answerIndex: Int
)

data class StudentProgress(
    val studentId: String,
    val courseId: String,
    val completedChapters: Int,
    val quizScore: Int
)
