package com.smartstudents.app.firebase

data class FirestoreUser(
    val uid: String = "",
    val name: String = "",
    val email: String = "",
    val role: String = "STUDENT",
    val className: String = "",
    val board: String = ""
)

data class FirestoreCourse(
    val id: String = "",
    val board: String = "",
    val className: String = "",
    val subject: String = "",
    val title: String = "",
    val published: Boolean = false
)

data class FirestoreProgress(
    val uid: String = "",
    val courseId: String = "",
    val completedLessons: Int = 0,
    val totalLessons: Int = 0,
    val bestQuizPercentage: Int = 0,
    val completedLessonIds: List<String> = emptyList()
)
