package com.smartstudents.app.firebase

import android.content.Context
import com.google.firebase.FirebaseApp
import com.google.firebase.appcheck.FirebaseAppCheck
import com.google.firebase.appcheck.playintegrity.PlayIntegrityAppCheckProviderFactory

/**
 * Installs Play Integrity-backed Firebase App Check for production Firebase builds.
 * Firebase configuration is detected at runtime, so demo/offline builds remain usable.
 */
object FirebaseSecurity {
    fun initialize(context: Context) {
        if (FirebaseApp.getApps(context.applicationContext).isEmpty()) return
        runCatching {
            FirebaseAppCheck.getInstance()
                .installAppCheckProviderFactory(
                    PlayIntegrityAppCheckProviderFactory.getInstance()
                )
        }
    }
}
