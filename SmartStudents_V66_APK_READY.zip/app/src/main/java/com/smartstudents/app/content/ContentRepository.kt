package com.smartstudents.app.content

class ContentRepository {
    private val courses = mutableListOf<ContentCourse>()

    fun add(course: ContentCourse) {
        courses.removeAll { it.id == course.id }
        courses.add(course)
    }

    fun publish(courseId: String) {
        courses.find { it.id == courseId }?.published = true
    }

    fun unpublish(courseId: String) {
        courses.find { it.id == courseId }?.published = false
    }

    fun publishedCourses(): List<ContentCourse> =
        courses.filter { it.published }.toList()
}

data class ContentCourse(
    val id: String,
    val title: String,
    val board: String,
    val className: String,
    val subject: String,
    var published: Boolean = false
)
