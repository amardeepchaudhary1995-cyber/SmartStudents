package com.smartstudents.app.notifications

/** Small in-memory notification inbox used by the UI. */
class NotificationCenter {
    private val items = mutableListOf<AppNotification>()

    fun add(notification: AppNotification) {
        items.add(0, notification)
    }

    fun all(): List<AppNotification> = items.toList()

    fun unreadCount(): Int = items.count { !it.read }

    fun markAllRead(): List<AppNotification> = items.map { it.copy(read = true) }.also {
        items.clear()
        items.addAll(it)
    }
}
