package com.smartstudents.app.auth

enum class UserRole { STUDENT, PARENT, ADMIN }

data class UserProfile(
    val id: String,
    val name: String,
    val email: String,
    val role: UserRole,
    val className: String = "",
    val board: String = ""
)
