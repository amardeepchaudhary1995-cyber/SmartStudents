package com.smartstudents.app.data

data class CatalogItem(
    val id: String,
    val title: String,
    val board: String,
    val className: String,
    val subject: String
)

object SmartStudentsCatalog {
    val boards = listOf("CBSE", "ICSE", "UP Board", "Bihar Board", "Rajasthan Board", "MP Board", "Maharashtra Board")
    val classes = listOf("LKG", "UKG") + (1..12).map { "Class $it" }
    val subjects = listOf("Mathematics", "Science", "English", "Hindi", "Social Science", "Computer")

    val demoCourses = listOf(
        CatalogItem("math-cbse-10", "Class 10 Mathematics", "CBSE", "Class 10", "Mathematics"),
        CatalogItem("sci-cbse-10", "Class 10 Science", "CBSE", "Class 10", "Science"),
        CatalogItem("eng-up-8", "Class 8 English", "UP Board", "Class 8", "English"),
        CatalogItem("hindi-bihar-6", "Class 6 Hindi", "Bihar Board", "Class 6", "Hindi")
    )

    fun search(query: String): List<CatalogItem> {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return demoCourses
        return demoCourses.filter {
            listOf(it.title, it.board, it.className, it.subject)
                .any { value -> value.lowercase().contains(q) }
        }
    }
}
