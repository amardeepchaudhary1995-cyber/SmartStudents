package com.smartstudents.app.content

import com.google.firebase.firestore.FirebaseFirestore
import com.smartstudents.app.data.CatalogItem
import com.smartstudents.app.ui.ChapterItem
import com.smartstudents.app.ui.CourseDetail
import com.smartstudents.app.ui.LessonItem

/**
 * Firestore content reader for the production learning hierarchy:
 * courses/{courseId}/chapters/{chapterId}/lessons/{lessonId}
 * and optional quizzes stored below lessons/{lessonId}/questions.
 */
class FirestoreContentRepository(private val db: FirebaseFirestore) {

    fun loadPublishedCourses(onResult: (List<CatalogItem>, Exception?) -> Unit) {
        db.collection("courses")
            .whereEqualTo("published", true)
            .get()
            .addOnSuccessListener { snapshot ->
                val result = snapshot.documents.mapNotNull { d ->
                    val id = d.id
                    val title = d.getString("title") ?: return@mapNotNull null
                    CatalogItem(
                        id = id,
                        title = title,
                        board = d.getString("board") ?: "",
                        className = d.getString("className") ?: "",
                        subject = d.getString("subject") ?: ""
                    )
                }
                onResult(result, null)
            }
            .addOnFailureListener { onResult(emptyList(), it) }
    }

    fun loadCourseDetail(courseId: String, onResult: (CourseDetail?, Exception?) -> Unit) {
        db.collection("courses").document(courseId).get()
            .addOnSuccessListener { courseDoc ->
                if (!courseDoc.exists()) {
                    onResult(null, IllegalStateException("Course not found"))
                    return@addOnSuccessListener
                }
                val base = CourseDetail(
                    id = courseDoc.id,
                    title = courseDoc.getString("title") ?: "Course",
                    board = courseDoc.getString("board") ?: "",
                    className = courseDoc.getString("className") ?: "",
                    subject = courseDoc.getString("subject") ?: "",
                    chapters = emptyList()
                )
                db.collection("courses").document(courseId).collection("chapters")
                    .orderBy("order")
                    .get()
                    .addOnSuccessListener { chaptersSnap ->
                        if (chaptersSnap.isEmpty) {
                            onResult(base, null)
                            return@addOnSuccessListener
                        }
                        val chapterDocs = chaptersSnap.documents
                        val chapterItems = mutableListOf<ChapterItem>()
                        var remaining = chapterDocs.size
                        var failed: Exception? = null
                        chapterDocs.forEach { chapterDoc ->
                            db.collection("courses").document(courseId)
                                .collection("chapters").document(chapterDoc.id)
                                .collection("lessons").orderBy("order").get()
                                .addOnSuccessListener { lessonsSnap ->
                                    val lessons = lessonsSnap.documents.map { d ->
                                        LessonItem(
                                            id = d.id,
                                            title = d.getString("title") ?: "Lesson",
                                            description = d.getString("description") ?: "",
                                            videoUrl = d.getString("videoUrl") ?: "",
                                            notesUrl = d.getString("notesUrl") ?: "",
                                            chapterId = chapterDoc.id
                                        )
                                    }
                                    synchronized(chapterItems) {
                                        chapterItems.add(
                                            ChapterItem(
                                                id = chapterDoc.id,
                                                title = chapterDoc.getString("title") ?: "Chapter",
                                                lessons = lessons
                                            )
                                        )
                                        remaining--
                                        if (remaining == 0) {
                                            val ordered = chapterDocs.mapNotNull { d ->
                                                chapterItems.firstOrNull { it.id == d.id }
                                            }
                                            onResult(base.copy(chapters = ordered), failed)
                                        }
                                    }
                                }
                                .addOnFailureListener {
                                    synchronized(chapterItems) {
                                        failed = it
                                        remaining--
                                        if (remaining == 0) onResult(base.copy(chapters = chapterItems), failed)
                                    }
                                }
                        }
                    }
                    .addOnFailureListener { onResult(base, it) }
            }
            .addOnFailureListener { onResult(null, it) }
    }
}
