package com.smartstudents.app.admin

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.google.firebase.storage.FirebaseStorage

@Composable
fun AdminCmsScreen(
    firebaseConfigured: Boolean,
    repo: AdminCmsRepository?,
    storageRepo: FirebaseStorageRepository?,
    onBack: () -> Unit
) {
    var courseId by remember { mutableStateOf("") }
    var title by remember { mutableStateOf("") }
    var board by remember { mutableStateOf("CBSE") }
    var cls by remember { mutableStateOf("Class 10") }
    var subject by remember { mutableStateOf("Mathematics") }
    var published by remember { mutableStateOf(false) }
    var chapterId by remember { mutableStateOf("ch1") }
    var chapterTitle by remember { mutableStateOf("") }
    var lessonId by remember { mutableStateOf("l1") }
    var lessonTitle by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var video by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var questionId by remember { mutableStateOf("q1") }
    var question by remember { mutableStateOf("") }
    var options by remember { mutableStateOf("A|B|C|D") }
    var answer by remember { mutableStateOf("0") }
    var message by remember { mutableStateOf("") }
    var uploading by remember { mutableStateOf(false) }

    fun save(action: (AdminCmsRepository, (Boolean, String?) -> Unit) -> Unit) {
        if (repo == null) { message = "Firebase configure होने पर CMS save होगा"; return }
        action(repo) { ok, error ->
            message = if (ok) "✓ Saved successfully" else "Error: ${error ?: "Unknown"}"
        }
    }

    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        if (storageRepo == null) { message = "Firebase Storage configure करें"; return@rememberLauncherForActivityResult }
        uploading = true
        message = "Video upload हो रहा है…"
        storageRepo.uploadMedia(uri, courseId, chapterId, lessonId, "video") { ok, url, error ->
            uploading = false
            if (ok && url != null) { video = url; message = "✓ Video uploaded. Lesson save करें." }
            else message = "Video upload error: ${error ?: "Unknown"}"
        }
    }

    val notesPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        if (storageRepo == null) { message = "Firebase Storage configure करें"; return@rememberLauncherForActivityResult }
        uploading = true
        message = "PDF/Notes upload हो रहा है…"
        storageRepo.uploadMedia(uri, courseId, chapterId, lessonId, "notes") { ok, url, error ->
            uploading = false
            if (ok && url != null) { notes = url; message = "✓ PDF uploaded. Lesson save करें." }
            else message = "PDF upload error: ${error ?: "Unknown"}"
        }
    }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text("Admin CMS • V23") },
            navigationIcon = { IconButton(onClick = onBack) { Text("‹") } }
        )
    }) { pad ->
        LazyColumn(
            Modifier.padding(pad).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item { Text("Course", style = MaterialTheme.typography.titleLarge) }
            item { Field(courseId, { courseId = it }, "Course ID") }
            item { Field(title, { title = it }, "Course title") }
            item { Field(board, { board = it }, "Board") }
            item { Field(cls, { cls = it }, "Class") }
            item { Field(subject, { subject = it }, "Subject") }
            item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Checkbox(published, { published = it }); Text("Published")
            }}
            item { Button(
                onClick = { save { r, d -> r.saveCourse(CmsCourse(courseId, title, board, cls, subject, published), d) } },
                Modifier.fillMaxWidth(), enabled = !uploading
            ) { Text("Save / Update Course") } }
            item { HorizontalDivider() }

            item { Text("Chapter", style = MaterialTheme.typography.titleLarge) }
            item { Field(chapterId, { chapterId = it }, "Chapter ID") }
            item { Field(chapterTitle, { chapterTitle = it }, "Chapter title") }
            item { Button(
                onClick = { save { r, d -> r.saveChapter(courseId, CmsChapter(chapterId, chapterTitle, 0), d) } },
                Modifier.fillMaxWidth(), enabled = !uploading
            ) { Text("Save Chapter") } }
            item { HorizontalDivider() }

            item { Text("Lesson + Media", style = MaterialTheme.typography.titleLarge) }
            item { Field(lessonId, { lessonId = it }, "Lesson ID") }
            item { Field(lessonTitle, { lessonTitle = it }, "Lesson title") }
            item { Field(description, { description = it }, "Description") }
            item { Field(video, { video = it }, "Video URL") }
            item { Button(
                onClick = { videoPicker.launch("video/*") },
                Modifier.fillMaxWidth(), enabled = !uploading
            ) { Text(if (uploading) "Uploading…" else "🎥 Upload Video") } }
            item { Field(notes, { notes = it }, "Notes / PDF URL") }
            item { OutlinedButton(
                onClick = { notesPicker.launch("application/pdf") },
                Modifier.fillMaxWidth(), enabled = !uploading
            ) { Text("📄 Upload PDF / Notes") } }
            item { Button(
                onClick = { save { r, d ->
                    r.saveLesson(courseId, chapterId, CmsLesson(lessonId, lessonTitle, description, video, notes, 0), d)
                } },
                Modifier.fillMaxWidth(), enabled = !uploading
            ) { Text("Save Lesson + Media") } }
            item { HorizontalDivider() }

            item { Text("Quiz Question", style = MaterialTheme.typography.titleLarge) }
            item { Field(questionId, { questionId = it }, "Question ID") }
            item { Field(question, { question = it }, "Question") }
            item { Field(options, { options = it }, "Options (A|B|C|D)") }
            item { Field(answer, { answer = it }, "Correct option index (0-3)") }
            item { Button(
                onClick = { save { r, d ->
                    r.saveQuestion(
                        courseId, chapterId, lessonId,
                        CmsQuestion(questionId, question, options.split("|").map { it.trim() }, answer.toIntOrNull() ?: 0, 0), d
                    )
                } },
                Modifier.fillMaxWidth(), enabled = !uploading
            ) { Text("Save Quiz Question") } }
            item { if (message.isNotBlank()) Text(message) }
            item { Text(
                "Storage path: courses/{course}/chapters/{chapter}/lessons/{lesson}/videos|notes/…",
                style = MaterialTheme.typography.bodySmall
            ) }
            item { Text(
                "Security: Firestore + Storage writes must be restricted to admin=true custom claim.",
                style = MaterialTheme.typography.bodySmall
            ) }
        }
    }
}

@Composable
private fun Field(value: String, onValue: (String) -> Unit, label: String) {
    OutlinedTextField(value, onValue, Modifier.fillMaxWidth(), label = { Text(label) }, singleLine = true)
}
