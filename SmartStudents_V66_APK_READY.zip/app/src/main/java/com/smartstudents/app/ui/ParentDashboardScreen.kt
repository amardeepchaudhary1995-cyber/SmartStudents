package com.smartstudents.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.Text
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun ParentProgressScreen(
    childName: String = "Student",
    coursesCompleted: Int = 0,
    lessonsCompleted: Int = 0,
    averageScore: Int = 0
) {
    Column(
        Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Parent Dashboard", style = MaterialTheme.typography.headlineSmall)
        Text("Progress for $childName")
        ProgressCard("Courses completed", coursesCompleted.toString())
        ProgressCard("Lessons completed", lessonsCompleted.toString())
        ProgressCard("Average quiz score", "$averageScore%")
    }
}

@Composable
private fun ProgressCard(label: String, value: String) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(label)
            Text(value, style = MaterialTheme.typography.headlineMedium)
        }
    }
}
