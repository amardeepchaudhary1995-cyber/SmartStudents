package com.smartstudents.app.admin

data class AdminCourseDraft(
    val id: String = "",
    val title: String = "",
    val board: String = "",
    val className: String = "",
    val subject: String = "",
    val description: String = "",
    val published: Boolean = false
)

data class AdminLessonDraft(
    val id: String = "",
    val chapterId: String = "",
    val title: String = "",
    val videoUrl: String = "",
    val notesUrl: String = "",
    val durationMinutes: Int = 0
)

data class AdminQuizDraft(
    val id: String = "",
    val lessonId: String = "",
    val title: String = "",
    val passingPercentage: Int = 40
)
