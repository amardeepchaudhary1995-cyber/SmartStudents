package com.smartstudents.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.Text
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.smartstudents.app.data.CourseProgress

@Composable
fun ProgressDashboardScreen(
    progress: List<CourseProgress> = emptyList()
) {
    Column(
        Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("My Progress", style = MaterialTheme.typography.headlineSmall)
        if (progress.isEmpty()) {
            Text("No course progress yet. Start a course to see your progress.")
        } else {
            progress.forEach { item ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text(item.courseId, style = MaterialTheme.typography.titleMedium)
                        Text("${item.completedLessons}/${item.totalLessons} lessons • ${item.completionPercent}% complete")
                        Text("Best quiz score: ${item.bestScore}%")
                    }
                }
            }
        }
    }
}
