package com.smartstudents.app.data

import android.content.Context
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth

data class CourseProgress(
    val courseId: String,
    val completedLessons: Int = 0,
    val totalLessons: Int = 0,
    val bestScore: Int = 0
) {
    val completionPercent: Int
        get() = if (totalLessons == 0) 0 else (completedLessons * 100) / totalLessons
}

/**
 * Local progress is namespaced by the active account.
 *
 * This prevents progress from one Firebase user appearing for another user
 * on the same device. Demo/offline mode uses a separate "demo" namespace.
 */
class LocalProgressStore(context: Context? = null) {
    private val appContext = context?.applicationContext
    private val prefs = appContext?.getSharedPreferences(
        "smart_students_progress_v21", Context.MODE_PRIVATE
    )
    private val progress = mutableMapOf<String, CourseProgress>()

    private fun namespace(): String {
        if (appContext == null) return "demo"
        return runCatching {
            if (FirebaseApp.getApps(appContext).isEmpty()) return@runCatching "demo"
            FirebaseAuth.getInstance().currentUser?.uid?.takeIf { it.isNotBlank() } ?: "demo"
        }.getOrDefault("demo")
    }

    private fun key(courseId: String, field: String) =
        "${namespace()}::${courseId}::$field"

    fun get(courseId: String): CourseProgress {
        val cacheKey = "${namespace()}::$courseId"
        progress[cacheKey]?.let { return it }
        val value = CourseProgress(
            courseId,
            prefs?.getInt(key(courseId, "completed"), 0) ?: 0,
            prefs?.getInt(key(courseId, "total"), 0) ?: 0,
            prefs?.getInt(key(courseId, "score"), 0) ?: 0
        )
        progress[cacheKey] = value
        return value
    }

    fun save(value: CourseProgress) {
        val cacheKey = "${namespace()}::${value.courseId}"
        progress[cacheKey] = value
        prefs?.edit()
            ?.putInt(key(value.courseId, "completed"), value.completedLessons)
            ?.putInt(key(value.courseId, "total"), value.totalLessons)
            ?.putInt(key(value.courseId, "score"), value.bestScore)
            ?.apply()
    }

    fun completedLessonIds(courseId: String): List<String> =
        (prefs?.getStringSet(key(courseId, "lessons"), emptySet()) ?: emptySet()).toList()

    fun isLessonCompleted(courseId: String, lessonId: String): Boolean =
        prefs?.getStringSet(key(courseId, "lessons"), emptySet())?.contains(lessonId) == true

    fun markLessonComplete(courseId: String, lessonId: String, totalLessons: Int): CourseProgress {
        val old = get(courseId)
        if (isLessonCompleted(courseId, lessonId)) return old.copy(totalLessons = totalLessons)
        val ids = (prefs?.getStringSet(key(courseId, "lessons"), emptySet()) ?: emptySet()).toMutableSet()
        ids.add(lessonId)
        val next = old.copy(
            completedLessons = ids.size.coerceAtMost(totalLessons),
            totalLessons = totalLessons
        )
        prefs?.edit()?.putStringSet(key(courseId, "lessons"), ids)?.apply()
        save(next)
        return next
    }

    fun saveQuizScore(courseId: String, score: Int, total: Int): CourseProgress {
        val old = get(courseId)
        val percent = if (total == 0) 0 else (score * 100) / total
        val next = old.copy(bestScore = maxOf(old.bestScore, percent))
        save(next)
        return next
    }
}
