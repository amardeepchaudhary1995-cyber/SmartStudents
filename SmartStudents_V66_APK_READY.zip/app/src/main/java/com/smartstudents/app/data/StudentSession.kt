package com.smartstudents.app.data

enum class AppRole { STUDENT, PARENT, ADMIN }

data class StudentSession(
    val uid: String = "",
    val name: String = "",
    val email: String = "",
    val role: AppRole = AppRole.STUDENT,
    val className: String = "",
    val board: String = "",
    val loggedIn: Boolean = false
)

class SessionManager {
    private var session = StudentSession()

    fun login(uid: String, name: String, email: String, role: AppRole, className: String = "", board: String = "") {
        session = StudentSession(uid, name, email, role, className, board, true)
    }

    fun logout() {
        session = StudentSession()
    }

    fun current(): StudentSession = session
}
