package com.smartstudents.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.smartstudents.app.notifications.Announcement
import com.smartstudents.app.notifications.AnnouncementRepository
import com.smartstudents.app.notifications.NotificationHelper
import android.content.Context

@Composable
fun AnnouncementsScreen(repo: AnnouncementRepository, context: Context, onBack:()->Unit) {
    var items by remember { mutableStateOf<List<Announcement>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) { repo.loadPublished { list,_ -> items=list; loading=false } }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) {
            Text("Announcements", style=MaterialTheme.typography.headlineSmall)
            TextButton(onClick=onBack){Text("Back")}
        }
        if(loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)) {
            items(items) { a ->
                Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement=Arrangement.spacedBy(6.dp)) {
                    Text(a.title, style=MaterialTheme.typography.titleMedium)
                    Text(a.body)
                    TextButton(onClick={NotificationHelper.show(context,a.title,a.body)}){Text("Notify me")}
                }}
            }
        }
    }
}
