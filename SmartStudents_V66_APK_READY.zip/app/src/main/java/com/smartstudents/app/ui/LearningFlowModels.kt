package com.smartstudents.app.ui

data class LessonItem(
    val id: String,
    val title: String,
    val description: String = "",
    val videoUrl: String = "",
    val notesUrl: String = "",
    val completed: Boolean = false,
    val chapterId: String = ""
)

data class ChapterItem(
    val id: String,
    val title: String,
    val lessons: List<LessonItem>
)

data class CourseDetail(
    val id: String,
    val title: String,
    val board: String,
    val className: String,
    val subject: String,
    val chapters: List<ChapterItem>
)

object DemoLearningFlow {
    val course = CourseDetail(
        id = "math-cbse-10",
        title = "Class 10 Mathematics",
        board = "CBSE",
        className = "Class 10",
        subject = "Mathematics",
        chapters = listOf(
            ChapterItem(
                "ch1",
                "Real Numbers",
                listOf(
                    LessonItem("l1", "Euclid's Division Lemma", "Concept explanation"),
                    LessonItem("l2", "Fundamental Theorem of Arithmetic", "Examples and practice"),
                    LessonItem("l3", "Chapter Practice", "Practice before quiz")
                )
            ),
            ChapterItem(
                "ch2",
                "Polynomials",
                listOf(
                    LessonItem("l4", "Introduction to Polynomials"),
                    LessonItem("l5", "Zeros of a Polynomial"),
                    LessonItem("l6", "Chapter Practice")
                )
            )
        )
    )
}
