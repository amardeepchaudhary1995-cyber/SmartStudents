package com.smartstudents.app.analytics

import android.content.Context
import com.google.firebase.FirebaseApp
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.analytics.logEvent
import com.google.firebase.crashlytics.FirebaseCrashlytics

/**
 * Optional Firebase Analytics/Crashlytics bridge.
 * It is a no-op when Firebase is not configured, preserving demo/offline mode.
 */
object AppTelemetry {
    private fun analytics(context: Context): FirebaseAnalytics? =
        if (FirebaseApp.getApps(context.applicationContext).isNotEmpty())
            FirebaseAnalytics.getInstance(context.applicationContext) else null

    private fun crashlytics(context: Context): FirebaseCrashlytics? =
        if (FirebaseApp.getApps(context.applicationContext).isNotEmpty())
            FirebaseCrashlytics.getInstance() else null

    fun sessionStarted(context: Context, uid: String?) {
        analytics(context)?.logEvent("session_started") {
            if (!uid.isNullOrBlank()) param("user_type", "authenticated") else param("user_type", "offline")
        }
        if (!uid.isNullOrBlank()) crashlytics(context)?.setUserId(uid)
    }

    fun login(context: Context, success: Boolean) {
        analytics(context)?.logEvent("login_result") { param("success", if (success) 1L else 0L) }
    }

    fun courseOpened(context: Context, courseId: String) {
        analytics(context)?.logEvent("course_opened") { param("course_id", courseId.take(100)) }
    }

    fun lessonOpened(context: Context, courseId: String, lessonId: String) {
        analytics(context)?.logEvent("lesson_opened") {
            param("course_id", courseId.take(100))
            param("lesson_id", lessonId.take(100))
        }
    }

    fun lessonCompleted(context: Context, courseId: String, lessonId: String) {
        analytics(context)?.logEvent("lesson_completed") {
            param("course_id", courseId.take(100))
            param("lesson_id", lessonId.take(100))
        }
    }

    fun quizCompleted(context: Context, courseId: String, correct: Int, total: Int) {
        analytics(context)?.logEvent("quiz_completed") {
            param("course_id", courseId.take(100))
            param("correct", correct.toLong())
            param("total", total.toLong())
            param("percentage", if (total > 0) (correct * 100L / total) else 0L)
        }
    }

    fun syncFailed(context: Context, courseId: String, reason: String?) {
        analytics(context)?.logEvent("progress_sync_failed") {
            param("course_id", courseId.take(100))
            param("reason", (reason ?: "unknown").take(100))
        }
    }

    fun nonFatal(context: Context, throwable: Throwable, area: String) {
        crashlytics(context)?.apply {
            setCustomKey("area", area)
            recordException(throwable)
        }
    }
}
