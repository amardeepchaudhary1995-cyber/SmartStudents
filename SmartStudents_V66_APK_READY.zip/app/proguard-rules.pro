# SmartStudents release rules
# Firebase/Android libraries provide their own consumer rules.
# Keep application model classes used by Firestore serialization.
-keep class com.smartstudents.app.** { *; }
