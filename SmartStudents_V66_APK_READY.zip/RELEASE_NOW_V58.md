# SmartStudents V58 — Release Now

V58 focuses on release safety rather than adding another app feature.

## Release pipeline hardening
- Signed production AAB is created first.
- AAB size/signing metadata and SHA-256 are verified before any external publish step.
- Checksum is re-verified before the immutable release manifest is created.
- Manifest records version, versionCode, AAB name, SHA-256, GitHub SHA, run ID, workflow and event.
- A final pre-publish verification step blocks Firebase/Google Play publication if the manifest/checksum is missing.
- Temporary Firebase/keystore credentials are removed with an always-run cleanup step.

## Local validation
Run:
```bash
python3 scripts/release_gate.py
python3 scripts/production_preflight.py
python3 scripts/release_readiness.py
python3 scripts/final_smoke.py
```

Actual Play publication still requires the configured GitHub secrets and Google Play/Firebase access.
