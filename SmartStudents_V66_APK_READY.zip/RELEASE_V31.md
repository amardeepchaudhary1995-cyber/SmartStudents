# Smart Students V31 — Parent Linking + Backend Security Fix

V31 fixes the parent-linking flow and moves sensitive linking operations to trusted callable Cloud Functions.

## What changed
- Parent link-code generation is now server-side and collision-resistant.
- Parent linking is now an atomic Cloud Function transaction.
- A client can no longer directly change `users/{studentUid}.parentUid`.
- Client access to `parentLinks/*` is fully denied; only callable functions can create/consume codes.
- The parent/student UI now supports both generating a code and entering a code.
- Version 31.

## Deploy
```bash
npm install --prefix functions
firebase deploy --only functions,firestore:rules
```

Because the new callables enforce App Check, production Firebase App Check must be configured before linking is used.

## Remaining release work
The app is code-complete for the planned feature set, but a real production release still needs:
1. Real Firebase project configuration and App Check setup.
2. Physical-device QA with parent/student accounts.
3. Release keystore and signed AAB.
4. Play Console listing, privacy policy, Data Safety review, and submission.
