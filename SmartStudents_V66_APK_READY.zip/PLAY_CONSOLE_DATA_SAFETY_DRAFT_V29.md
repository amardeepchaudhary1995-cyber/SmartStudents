# Play Console Data Safety — Draft

This is a checklist, not a legal declaration. Confirm every answer against the exact production configuration before submitting.

## Potentially collected/shared data
- Name/email: collected when Firebase Authentication account data is used.
- App activity: course/lesson/quiz activity may be collected through Analytics if enabled.
- App performance/diagnostics: Crashlytics may collect crash and diagnostic data.
- App information/device identifiers: Firebase services may process technical identifiers and notification tokens.
- User-generated/education data: progress, quiz results and parent/student linkage data are stored in Firestore when enabled.

## Review before submission
- [ ] Confirm whether each data type is actually collected in the production build.
- [ ] Confirm whether data is shared with service providers and for which purpose.
- [ ] Confirm encryption in transit and any encryption-at-rest claims.
- [ ] Confirm deletion/request workflow.
- [ ] Confirm account creation and account deletion options.
- [ ] Confirm child-directed/under-13 handling and parental consent requirements.
- [ ] Confirm the privacy policy URL is publicly accessible.
- [ ] Complete the Play Console questionnaire using the final answers.
