# SmartStudents V55 — Battery & Background Efficiency

V55 is a release-candidate hardening pass focused on reducing unnecessary background work.

- Network callback is registered only while the main activity is visible and released in `onStop()`.
- Progress sync reuses one Firebase gateway instead of repeatedly constructing gateways for network recovery.
- FCM topic subscription state is cached per Firebase UID to avoid repeated subscription requests.
- FCM subscription state is cleared on logout so the next account can register cleanly.
- Existing release signing, Firebase deployment, Play Internal Testing, checksum and manifest gates remain unchanged.

## Validation

Run:
- `python3 scripts/release_gate.py`
- `python3 scripts/production_preflight.py`
- `python3 scripts/release_readiness.py`
- `python3 scripts/final_smoke.py`

Battery impact should be verified on a physical device with Android battery usage after a normal day of foreground/background use.
