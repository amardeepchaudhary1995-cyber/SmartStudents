# SmartStudents V59 — Release Now

V59 hardens release provenance. The immutable manifest records version, versionCode, AAB, SHA-256, GitHub commit SHA, run ID, workflow and triggering event.

Execution path: signed AAB → verification → optional Firebase deployment → optional Play Internal Testing → retained release artifacts.
