# SmartStudents V44 Release Notes

## Changes
- Improved Firebase login UX with real authentication failure feedback.
- Added busy/loading state to prevent duplicate login taps while authentication is running.
- Added Show/Hide password control while keeping the password masked by default.
- Strengthened email validation using Android's email pattern matcher and normalized email input.
- Login failures are now surfaced to the user instead of silently leaving the screen unchanged.
- Offline/demo login behavior remains unchanged.
- Version code: 44.

## Validation
- Release Gate: PASS.
- Production Preflight: PASS (existing Gradle wrapper warning remains).
- Kotlin source brace/parenthesis balance checks: PASS.
- Firebase Functions Node syntax check: PASS.
- Android APK/AAB compilation requires an Android SDK/Gradle environment.
