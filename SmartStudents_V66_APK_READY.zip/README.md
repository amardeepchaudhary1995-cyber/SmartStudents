## V66 Release Candidate
Internal Testing preflight ordering fixed so the exact verified AAB is present before Play validation.

## V65 — Internal Testing Release Candidate

V65 is prepared for Google Play Internal testing. The workflow now performs an explicit internal-track preflight against the exact verified AAB before Play upload.\n\n## V64 release-candidate hardening

V64 validates requested Firebase and Google Play credentials before the signed production build, reducing failed-release wait time while preserving the cryptographic AAB verification gate.

# SmartStudents V63 — Release Candidate hardening

V63 fixes the final pre-publish checksum verification path and records the application ID in the immutable release manifest.

# SmartStudents V62 — Release Candidate Hardening

V62 keeps the V61 release candidate intact and fixes the final cryptographic verification path before Google Play Internal Testing.

# SmartStudents V60 — Release-safe publish ordering

# V59 Release Candidate

Release provenance manifest corrected to record GitHub run ID, workflow, event, commit SHA and AAB checksum accurately.

# SmartStudents V58 Release Candidate

V58 hardens the release pipeline so the signed AAB is verified and its immutable manifest is created before Firebase/Google Play external side effects.

# SmartStudents V57

Release candidate with foreground network retry throttling to reduce duplicate background/foreground sync wakeups.

# SmartStudents V56 — Release integrity hardening

V56 adds a final checksum/provenance verification gate so the exact production AAB and immutable release manifest are verified before artifact upload. The release path remains optimized for fast Internal Testing delivery.

# SmartStudents V55 — Battery/background efficiency release candidate

V55 reduces unnecessary background network observation and repeated FCM subscription work while preserving the production release pipeline.

# SmartStudents — V54 Release Candidate

V54 removes the unnecessary debug APK build from manual production releases by default, so the release path reaches the signed AAB, Firebase deployment and Google Play Internal Testing faster. Debug smoke remains available as an explicit workflow option.

# SmartStudents — V53 Release Candidate

V53 is focused on the shortest path from signed production build to Google Play Internal Testing, with release provenance, fail-fast credential checks, Firebase deployment, checksum verification and cleanup.

# SmartStudents V52 — Release Candidate\n\nV52 is the release-focused build: version 52, hardened GitHub release workflow, immutable AAB checksum/manifest artifacts, Firebase production deployment, and optional Google Play Internal testing publishing.\n\n# SmartStudents — V51 Release Candidate

V51 is the release-handoff build. It adds a signed-AAB verification gate and SHA-256 release artifact so the exact bundle uploaded to Google Play can be independently checked before rollout.

# SmartStudents — V50 Release Candidate

V50 is the release-focused build: CI now validates all release credentials before attempting Firebase or Google Play operations, fixes the Firebase deploy environment, and keeps signed AAB + backend deployment + Internal testing publishing in one controlled workflow.

# Smart Students V49 — One-Run Production Release

V49 automates signed AAB creation, Firebase backend deployment, and optional Google Play Internal testing upload. See `RELEASE_NOW_V49.md`.

# Smart Students V48 — Final Release Handoff

V48 makes the production AAB workflow explicit and fail-fast, adds stronger auth validation, and adds a fast source smoke test. See `RELEASE_V48.md`.

# Smart Students V47 — Final Release Readiness

V47 consolidates the final production handoff: CI now runs release gate, production preflight, and a secret-presence readiness check before Android builds. See `RELEASE_V47.md`.

# Smart Students V46 — Privacy & Data Transparency

V46 adds an in-app Privacy & data summary from Profile so users can understand account, progress, notifications, analytics/crash reporting, and account deletion before release.

See `RELEASE_V46.md`.

# Smart Students V45 — Production Release Candidate

V45 adds automatic Firebase session-state guarding so protected UI cannot remain visible after sign-out, account deletion, or session loss. See `RELEASE_V45.md`.

# Smart Students V44 — Production Release Candidate

V44 improves authentication feedback and prevents duplicate login submissions while preserving the offline/demo fallback. See `RELEASE_V44.md`.

# Smart Students V41 — Production Release Candidate

V41 isolates local learning progress per signed-in account to prevent cross-account progress leakage on shared devices. See `RELEASE_V41.md`.

# Smart Students V39 — Production Release Candidate

V39 hardens the production release pipeline so a signed production AAB is only attempted when all required Firebase and signing secrets are available. See `RELEASE_V39.md`.

# Smart Students V38 — Production Release Candidate

V38 adds the required Android INTERNET permission for Firebase-backed production features and continues release hardening.

# Smart Students V35 — Production Release Candidate

V35 continues the production-release hardening from the V33 release candidate into a safer, reproducible production candidate.

### V29 release engineering
- Conditional Google Services + Crashlytics Gradle plugins: the project remains buildable in demo mode when `google-services.json` is absent.
- Environment-variable based release signing; no keystore/password is committed.
- CI workflow builds the debug APK and can build a signed release AAB when signing secrets and Firebase configuration are supplied.
- Privacy policy and Play Console Data Safety draft are included for final review.
- Final release checklist covers Firebase deployment, signing, device QA and Play Console submission.

# Smart Students V29

## V22 — Firebase Storage Media Upload

V23 adds Parent/Student linking, announcements, and on-device notifications on top of the V22 Firebase Storage release.

### Admin features
- Create/update courses, chapters, lessons and quiz questions.
- Pick a video directly from the Android device and upload it to Firebase Storage.
- Pick a PDF/notes file directly from the Android device and upload it.
- Uploaded download URLs are automatically placed into the lesson's Video URL / Notes URL fields.
- Save the lesson after upload to persist those URLs in Firestore.
- Upload controls are disabled while a media upload is running.

### Storage layout

```text
courses/{courseId}/chapters/{chapterId}/lessons/{lessonId}/videos/{timestamp}.mp4
courses/{courseId}/chapters/{chapterId}/lessons/{lessonId}/notes/{timestamp}.pdf
```

### Firebase setup
1. Put `google-services.json` in `app/`.
2. Enable Email/Password Authentication.
3. Create Firestore and deploy `firestore.rules`.
4. Enable Firebase Storage.
5. Deploy `storage.rules`.
6. Give trusted admin accounts the Firebase custom claim `admin=true`.
7. Open Admin CMS, enter Course/Chapter/Lesson IDs, upload video/PDF, then press **Save Lesson + Media**.
8. Students can then open the saved video/PDF links from the lesson screen.

### Security
- Firestore writes remain protected by `admin=true`.
- Storage uploads/deletes require `admin=true`.
- Authenticated users can read lesson media.
- No Firebase credentials are included in this ZIP.

### V23+ roadmap
1. Parent-child linking, announcements and push notifications.
2. Offline-first sync and server-side progress validation.
3. Production QA, security audit, analytics/crash reporting and Play Store release.

V22 remains compatible with the existing offline/demo learning experience when Firebase is not configured.


## V23 — Parent Linking + Announcements

### Parent / Student linking
- Student can generate a one-time 6-character parent link code from the dashboard.
- Parent can use the code through the same Firebase account flow; the link is stored under `users/{parentUid}/children/{studentUid}`.
- The student's `users/{studentUid}.parentUid` is set during linking.
- Firestore rules restrict link creation to the student and child records to the parent.

### Announcements
- Admin can publish announcement documents in `announcements`.
- Authenticated students can read only published announcements.
- The app can display an announcement as a local Android notification after the user grants notification permission.
- This is the notification foundation; true server-triggered push delivery can be added with Firebase Cloud Messaging in the final release stage.

### Firestore examples
```text
parentLinks/{code}
  studentUid: string
  used: boolean
  createdAt: timestamp
  parentUid: string (after linking)

users/{parentUid}/children/{studentUid}
  studentUid: string
  linkedAt: timestamp

announcements/{announcementId}
  title: string
  body: string
  published: boolean
  createdAt: number
```

### V24+ roadmap
1. Offline-first sync and server-side progress validation.
2. FCM push delivery, analytics/crash reporting and production security audit.
3. Final QA, release signing and Play Store production build.


## V24 — Offline-first sync + trusted progress validation

V24 hardens progress syncing for real-world network loss.

### Offline-first progress
- Lesson completion and quiz scores are still saved locally first.
- Each course keeps a small pending sync record in `SharedPreferences`.
- Pending progress is retried when the app starts and when Android reports network availability.
- The latest local state for each course is queued, avoiding a growing upload backlog.

### Trusted server-side validation
- Android no longer writes `users/{uid}/progress/{courseId}` directly.
- The `submitProgress` Firebase callable Cloud Function checks authentication.
- It verifies the course is published.
- It loads the real lesson IDs from Firestore and ignores unknown/fake lesson IDs.
- It calculates the completed lesson count from valid IDs and the real lesson total.
- Quiz percentage is clamped to 0–100 and the server keeps the best score.
- The Firestore rules allow users to read their own progress but deny client writes.

### Deploy V24 backend
From the project root:
```bash
npm install --prefix functions
firebase deploy --only functions,firestore:rules
```

The Firebase CLI project must be selected/configured before deployment. The Android app can still run in local/demo mode without Firebase.

### Important
V24 adds a real trusted backend validation path, but it does not yet include FCM push delivery, analytics/crash reporting, release signing, or Play Store production QA. Those remain in the final release stage.


## V25 — Firebase Cloud Messaging push notifications

V25 adds real server-triggered push notifications for published announcements.

### Push flow
1. Android asks for notification permission on Android 13+.
2. Logged-in Firebase users subscribe to the `all_students` FCM topic.
3. `SmartStudentsMessagingService` handles foreground messages and displays the existing announcement notification.
4. A Cloud Function watches `announcements/{announcementId}`.
5. When a new announcement has `published=true`, the function sends an FCM notification to `all_students`.
6. The announcement remains in Firestore, so the in-app Announcements screen still shows the full message.

### Deploy
```bash
npm install --prefix functions
firebase deploy --only functions,firestore:rules
```

FCM uses Firebase's server credentials internally; no service-account key is included in the Android project.

### Important
Push delivery requires a real Firebase project and `google-services.json`. Local/demo mode continues to work, but server push is unavailable until Firebase is configured and the V25 functions are deployed.

\n## V26 — Analytics + Crash Reporting + production telemetry
\nV26 adds optional Firebase Analytics and Crashlytics instrumentation while keeping offline/demo mode safe.
\n
### Analytics events
- `session_started` — app session starts.
- `login_result` — login/continue result.
- `course_opened` — a course is opened.
- `lesson_opened` / `lesson_completed` — lesson engagement.
- `quiz_completed` — quiz score and percentage.
- `progress_sync_failed` — a cloud progress retry failed.

### Crash reporting
- Firebase Crashlytics records non-fatal sync failures with the course ID and area.
- Crashlytics automatically captures uncaught production crashes when Firebase is configured.
- Authenticated Firebase users are assigned as the Crashlytics user ID.

### Firebase setup
1. Put your real `google-services.json` in `app/`.
2. In the final production build, enable the Google Services/Crashlytics Gradle plugins as required by your Firebase project.
3. Enable Analytics and Crashlytics in the Firebase console.
4. Deploy the V25 functions and Firestore/Storage rules.
5. Test Analytics DebugView and Crashlytics test reports on a development device before release.

No analytics or crash data is sent in offline/demo mode because Firebase is not initialized.


## V27 — Final Security + QA hardening

V27 is the production-hardening pass before release. Firestore client writes for progress and parent-child records are tightened, student profile updates cannot change `parentUid`, and announcement push notifications now also fire when a draft is later published. See `FINAL_QA_V27.md` for the complete security, offline, Firebase, notification and release checklist.


## V28 Release
See `RELEASE_V28.md` and `PLAY_STORE_CHECKLIST_V28.md` for the signed AAB and Play Store preparation steps.


## V30 — Production App Check + Security Gate

V30 adds Firebase App Check backed by Play Integrity. The Android app installs the App Check provider only when Firebase is configured, while the trusted `submitProgress` callable now requires App Check. A local release-gate script checks the version, App Check dependency, and accidental secret/API-key files.

Before production, configure App Check in Firebase, complete real-device QA, and only then enable broader Firestore/Storage enforcement. Run `python scripts/release_gate.py` from `ss15`.


## V31 — Parent Linking Security Fix

V31 moves parent-link code generation and parent linking to trusted App Check-protected callable functions. Direct client writes to `parentLinks/*` and direct changes to a student's `parentUid` are blocked by Firestore rules. The UI supports both generating and entering a 6-character code.

Deploy with `npm install --prefix functions` followed by `firebase deploy --only functions,firestore:rules`.


## V32 — Account deletion + production privacy readiness

V32 adds a user-controlled account deletion flow required for a production education app.

### Account deletion
- Profile now includes **Delete account** with an explicit confirmation dialog.
- Firebase users can invoke the `deleteMyAccount` callable Cloud Function.
- The function requires authentication and App Check.
- It deletes the signed-in user's `users/{uid}` document and owned subcollections, removes parent-link records that reference the account, and finally deletes the Firebase Authentication account.
- Admin-owned course content is never deleted by this endpoint.
- Local pending progress is cleared after successful deletion.

### Production deployment
Deploy the updated Functions before enabling account deletion in production:

```bash
firebase deploy --only functions,firestore,storage
```

Before Play Store submission, verify account deletion on a real Firebase project and update the Privacy Policy/Data Safety answers to match the final data retention and deletion behavior.

## V33 — Stabilization / release-blocker fixes

V33 fixes source-generation defects discovered in the V32 package: invalid literal newline escapes in the Firebase Functions entry point and Profile Compose screen. The release gate is now version-aware and also checks Node function syntax, Firebase dependencies, accidental literal newline escapes, API-key/private-key patterns, and forbidden credential files.


## V35 — Production data-integrity + account-lifecycle hardening

V35 fixes three important release-stage issues:

- Firebase login/profile writes now use Firestore merge semantics. A normal login can no longer overwrite server-owned fields such as `parentUid`.
- Logout unsubscribes the device from the `all_students` FCM topic before signing out, reducing notifications after logout.
- Account deletion now also removes a student's `users/{parentUid}/children/{studentUid}` reference using a Firestore collection-group query, in addition to deleting the user's own data and link records.

### V35 release gate

Run:

```bash
python scripts/release_gate.py
```

The gate checks version consistency, Firebase dependencies, secret-file hygiene, Node function syntax, and the V35 data-integrity safeguards.

### Important production test

Before Play Store release, test these flows on a real Firebase project:

1. Link a student to a parent.
2. Log the student out and back in; verify `parentUid` is still present.
3. Log out a student device; verify it no longer receives `all_students` notifications.
4. Delete a student account; verify the parent's child reference disappears.
5. Delete a parent account; verify its child references and link records are removed.


## V36 — account-isolated offline queue + CI release hardening

V36 closes a production data-isolation edge case in offline progress syncing:

- Pending progress is now keyed by Firebase UID + course ID.
- A newly signed-in account cannot inherit queued progress from a previous account.
- Logout clears the previous account's pending sync queue.
- The CI workflow now uploads the correct debug APK path.
- Temporary `google-services.json` and release keystore files are removed from the CI workspace after builds.
- `scripts/production_preflight.py` checks versioning, backend files, CI artifact paths, secret hygiene and Cloud Functions syntax.

### V36 verification

```bash
python scripts/release_gate.py
python scripts/production_preflight.py
```

Both are static repository checks. A real Android build still requires Android SDK/Gradle and, for a production build, the Firebase project and signing secrets.


## V40
V40 is the current release candidate. It fixes the missing FirebaseSecurity import and hardens the CI signing/build workflow. See `RELEASE_V40.md`.


## V42 — Authentication session integrity
V42 makes Firebase authentication state authoritative in cloud mode, preventing a stale local login flag from bypassing the login screen after the Firebase session is gone. Offline/demo mode remains unchanged.


## V43
- Improved login form validation and password masking.
- Added email/password keyboard hints and visible validation errors.
