# SmartStudents V52 — Release Now

V52 is a release-candidate hardening pass, not a feature detour.

## Release pipeline
1. Release gate, production preflight, readiness and source smoke checks run.
2. Required signing/Firebase/Google services secrets are fail-fast validated.
3. Signed production AAB is built with Gradle 8.9.
4. AAB is checked for existence/non-empty output and signing metadata.
5. SHA-256 checksum and immutable release manifest are generated.
6. Firebase Firestore rules, Storage rules and Functions can deploy in the same run.
7. Google Play Internal testing can receive the exact AAB when `publish_internal=true`.
8. Temporary production credentials are deleted in an `always()` cleanup step.

## Workflow dispatch
Run **Android release** manually with:
- `build_release = true`
- `deploy_firebase = true`
- `publish_internal = true` for Play Internal testing

## Required GitHub secrets
- `SMARTSTUDENTS_KEYSTORE_BASE64`
- `SMARTSTUDENTS_KEYSTORE_PASSWORD`
- `SMARTSTUDENTS_KEY_ALIAS`
- `SMARTSTUDENTS_KEY_PASSWORD`
- `GOOGLE_SERVICES_JSON_B64`
- `FIREBASE_SERVICE_ACCOUNT_JSON`
- `FIREBASE_PROJECT_ID`
- `GOOGLE_PLAY_SERVICE_ACCOUNT_JSON` (only for Play upload)

## Final owner-side gate
The remaining release action requires the project's authorized GitHub/Firebase/Google Play accounts and a physical-device QA pass. The repository cannot safely invent or bypass those credentials.
