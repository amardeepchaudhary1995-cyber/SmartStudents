# Smart Students V47 — Final Release Runbook

V47 is the **release-readiness build**. It does not add another user-facing feature; it removes ambiguity from the final production handoff.

## What is automated

CI now runs, before building:
1. `scripts/release_gate.py`
2. `scripts/production_preflight.py`
3. `scripts/release_readiness.py`
4. Debug APK build
5. Signed release AAB build when all production secrets are configured
6. Temporary Firebase/signing files are removed
7. AAB/APK artifacts are uploaded

## Five CI secrets required for a production AAB

Configure these GitHub Actions repository secrets:

- `SMARTSTUDENTS_KEYSTORE_BASE64`
- `SMARTSTUDENTS_KEYSTORE_PASSWORD`
- `SMARTSTUDENTS_KEY_ALIAS`
- `SMARTSTUDENTS_KEY_PASSWORD`
- `GOOGLE_SERVICES_JSON_B64`

The readiness script checks only whether these variables exist; it never prints their values.

## Final Firebase checks

Before Play Console upload:
- Deploy Firestore rules.
- Deploy Storage rules.
- Deploy Cloud Functions.
- Verify App Check enforcement.
- Create/verify the production admin account.
- Test Email/Password sign-in on a physical device.
- Test course → lesson → video/PDF → quiz → progress sync.
- Test parent link and notification delivery.
- Test account deletion and re-login.

## Play Console handoff

Complete:
- Privacy Policy URL
- Data Safety form
- Content rating
- Target audience
- Store listing and screenshots
- Internal testing
- Closed testing if required
- Production rollout approval

## Important limitation

This environment does not contain the Android SDK or production Firebase credentials, so the signed AAB cannot be truthfully claimed as built here. The repository is prepared so CI can perform the real production build once the five secrets are configured.
