# Smart Students V33 — Production blocker fix

V33 is a stabilization release focused on fixing source-generation defects found during the V32 release gate.

## Fixed
- Corrected an invalid literal `\\n` in `functions/index.js` that prevented Node syntax validation and Firebase Functions deployment.
- Corrected the same literal-newline issue in the Compose profile screen.
- Bumped Android `versionCode` and project version to 33.
- Updated the release gate so it validates the current version, Firebase dependencies, secret hygiene, Node function syntax, and accidental literal newline escapes.
- Kept account deletion visible in the Profile screen.

## Verification
Run from the `ss15` directory:

```bash
python3 scripts/release_gate.py
node --check functions/index.js
```

If Gradle is available on the release machine:

```bash
gradle :app:assembleDebug
```

For production, add the real Firebase project configuration and release signing secrets only through the developer/CI environment; never commit them.


V34 follow-up: see README.md for the V34 data-integrity and account-lifecycle hardening pass.
