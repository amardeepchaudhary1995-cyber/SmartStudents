# SmartStudents V28 — Release & Play Store Preparation

## Release status
V28 is the release-preparation build. It is configured with:
- versionCode 28
- versionName 1.0.0
- release build type
- R8/minification disabled for the first production validation pass
- no signing secrets committed to the repository

## Before building the AAB
1. Create/configure the Firebase project.
2. Put the real `google-services.json` in `app/`.
3. Enable Authentication, Firestore, Storage, Functions and Cloud Messaging as required.
4. Deploy Firestore/Storage rules and Cloud Functions.
5. Create a release keystore and keep it outside the project.
6. Configure Android Studio/CI signing using environment variables or the local signing UI.
7. Build a signed release AAB.
8. Test the signed release on at least two Android devices.

## Required production checks
- Login/logout and account recovery
- Student/parent linking
- Published course visibility
- Video/PDF opening and Storage permissions
- Lesson completion and quiz score validation
- Offline progress and retry sync
- FCM notification delivery
- Analytics events
- Crash reporting
- Admin-only operations
- Firestore and Storage security rules
- Android 13+ notification permission
- App startup with Firebase unavailable

## Play Store
Prepare:
- signed `.aab`
- app icon and screenshots
- short/full description
- privacy policy URL
- Data safety answers
- content rating
- target audience declaration
- support email
- store listing graphics

Do not upload `google-services.json` containing production configuration to public repositories, and never commit a keystore/private key.
