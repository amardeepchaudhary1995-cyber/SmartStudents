# Smart Students V48 — Release Handoff

V48 is the final release-engineering hardening pass before real Firebase/Play Console work.

## Changes
- Added stronger email normalization/validation and bounded password validation.
- Added a fast source-level smoke test covering auth session lifecycle, notifications, profile privacy/account actions, and release versioning.
- CI now runs the smoke test before Android builds.
- Production AAB creation is now explicit: use **workflow_dispatch → build_release=true**.
- A requested production build fails immediately when any of the five required secrets is missing, instead of silently skipping the AAB.
- Production credentials are still written only temporarily and removed after the build.

## Remaining real-world work
1. Configure the five GitHub Actions secrets.
2. Run workflow with `build_release=true` and download the signed AAB artifact.
3. Deploy/verify Firebase rules, Storage and Functions.
4. Perform physical-device QA.
5. Complete Play Console forms and testing tracks.
