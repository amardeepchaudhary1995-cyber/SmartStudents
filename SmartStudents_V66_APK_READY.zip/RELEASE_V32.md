# Smart Students V32 — Production Privacy & Account Deletion

## Completed
- User-facing permanent account deletion.
- Callable backend deletion endpoint with App Check.
- Firebase Auth account deletion after Firestore cleanup.
- Parent-link cleanup.
- Local pending-sync queue cleared after successful deletion.
- Release version: 32.

## Required before production
1. Deploy Functions and Firestore/Storage rules to the real Firebase project.
2. Test account deletion with a real student and parent-linked account.
3. Confirm the user can register again after deletion.
4. Confirm admin courses remain intact.
5. Update Play Console Data Safety and Privacy Policy to reflect actual retention.
6. Build and test a signed AAB on physical Android devices.
