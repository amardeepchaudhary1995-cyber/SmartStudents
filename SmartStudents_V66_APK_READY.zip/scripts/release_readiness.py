#!/usr/bin/env python3
"""Smart Students V48 production release readiness check."""
from pathlib import Path
import os, re, sys

ROOT = Path(__file__).resolve().parents[1]
errors=[]

required_files = [
    "VERSION", "app/build.gradle.kts", "firestore.rules", "storage.rules",
    "functions/index.js", ".github/workflows/android-release.yml",
    "PRIVACY_POLICY_DRAFT_V29.md", "PLAY_CONSOLE_DATA_SAFETY_DRAFT_V29.md",
    "PLAY_STORE_CHECKLIST_V28.md"
]
for rel in required_files:
    if not (ROOT/rel).exists():
        errors.append(f"Missing release file: {rel}")

version=(ROOT/"VERSION").read_text().strip()
m=re.fullmatch(r"V(\d+)",version)
gradle=(ROOT/"app/build.gradle.kts").read_text(errors="ignore")
if not m:
    errors.append("VERSION must be V<number>")
else:
    code=int(m.group(1))
    if not re.search(rf"versionCode\s*=\s*{code}\b",gradle):
        errors.append(f"versionCode does not match {version}")

# Production secrets are checked by presence only; values are never printed.
secret_names=[
    "SMARTSTUDENTS_KEYSTORE_BASE64",
    "SMARTSTUDENTS_KEYSTORE_PASSWORD",
    "SMARTSTUDENTS_KEY_ALIAS",
    "SMARTSTUDENTS_KEY_PASSWORD",
    "GOOGLE_SERVICES_JSON_B64",
]
missing=[n for n in secret_names if not os.getenv(n)]
print(f"SmartStudents {version} — production readiness")
print(f"Repository checks: {'PASS' if not errors else 'FAIL'}")
print("CI production secrets:", "READY" if not missing else f"NOT CONFIGURED ({len(missing)} missing)")

if errors:
    for e in errors: print(" -",e)
    sys.exit(1)

workflow=(ROOT/".github/workflows/android-release.yml").read_text(errors="ignore")
workflow_checks=[
    ("FIREBASE_SERVICE_ACCOUNT_JSON", "Firebase service-account secret is not referenced"),
    ("FIREBASE_PROJECT_ID", "Firebase project-id secret is not referenced"),
    ("GOOGLE_PLAY_SERVICE_ACCOUNT_JSON", "Google Play service-account secret is not referenced"),
    ("gradle :app:bundleRelease", "Signed production AAB build command is missing"),
    ("app/build/outputs/bundle/release/*.aab", "Release AAB artifact path is missing"),
]
for needle,msg in workflow_checks:
    if needle not in workflow: errors.append(msg)

if errors:
    print("\nRelease workflow checks: FAIL")
    for e in errors: print(" -",e)
    sys.exit(1)

print("\nRelease workflow checks: PASS")
print("\nNext action:")
if missing:
    print("  Configure the 5 Android CI secrets, then run the Android release workflow.")
else:
    print("  Run the Android release workflow with build_release=true.")
