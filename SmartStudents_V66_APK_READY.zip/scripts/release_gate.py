#!/usr/bin/env python3
"""Smart Students V41 offline release gate."""
from pathlib import Path
import re, sys, subprocess
ROOT = Path(__file__).resolve().parents[1]
errors=[]
version=(ROOT/"VERSION").read_text().strip()
mver=re.fullmatch(r"V(\d+)", version)
expected_code=int(mver.group(1)) if mver else None
gradle=(ROOT/"app/build.gradle.kts").read_text(errors="ignore")
m=re.search(r'versionCode\s*=\s*(\d+)', gradle)
vc=int(m.group(1)) if m else None
if expected_code is None: errors.append(f"Invalid VERSION file: {version!r}")
if vc != expected_code: errors.append(f"versionCode is {vc}, expected {expected_code}")
for dep in ['firebase-appcheck-playintegrity','firebase-crashlytics','firebase-messaging']:
    if dep not in gradle: errors.append(f"Required dependency missing: {dep}")
for bad in ['google-services.json','release.keystore','serviceAccountKey.json']:
    if (ROOT/'app'/bad).exists() or (ROOT/bad).exists(): errors.append(f"Secret/build credential file present: {bad}")
manifest=ROOT/"app/src/main/AndroidManifest.xml"
if manifest.exists() and "android.permission.INTERNET" not in manifest.read_text(errors="ignore"):
    errors.append("AndroidManifest.xml is missing INTERNET permission")
for p in ROOT.rglob('*'):
    if p.is_file() and '.git' not in p.parts and p.suffix in {'.kt','.kts','.js','.json','.md','.xml','.properties','.yml','.yaml'}:
        try: text=p.read_text(errors='ignore')
        except Exception: continue
        if re.search(r'AIza[0-9A-Za-z_-]{20,}', text): errors.append(f"Possible Google API key in {p.relative_to(ROOT)}")
        if 'BEGIN PRIVATE KEY' in text: errors.append(f"Possible private key in {p.relative_to(ROOT)}")
decls={}
for p in (ROOT/"app/src/main").rglob("*.kt"):
    text=p.read_text(errors="ignore")
    for kind,name in re.findall(r"^\s*(?:data\s+)?(class|object|interface)\s+([A-Za-z_][A-Za-z0-9_]*)",text,re.M):
        decls.setdefault((kind,name),[]).append(p)
for (kind,name), paths in decls.items():
    if len(paths)>1: errors.append(f"Duplicate Kotlin top-level {kind} {name}: {', '.join(str(p.relative_to(ROOT)) for p in paths)}")
gateway=(ROOT/"app/src/main/java/com/smartstudents/app/firebase/FirebaseGateway.kt").read_text(errors="ignore")
local_store=(ROOT/"app/src/main/java/com/smartstudents/app/data/LocalProgressStore.kt").read_text(errors="ignore")
if "FirebaseAuth.getInstance().currentUser?.uid" not in local_store or '"demo"' not in local_store:
    errors.append("Local progress store must isolate data by active Firebase UID and demo namespace")

checks=[
("SetOptions.merge()","Firebase profile writes must use merge semantics"),
('unsubscribeFromTopic("all_students")',"Firebase logout must unsubscribe from the student notification topic"),
('uid}::${progress.courseId}',"Offline progress queue must be scoped by Firebase UID and course"),
('queuePrefs.edit().clear().apply()',"Logout must clear pending progress belonging to the previous account"),
]
for needle,msg in checks:
    if needle not in gateway: errors.append(msg)
functions=(ROOT/"functions/index.js").read_text(errors="ignore")
for needle,msg in [('collectionGroup("children")',"Account deletion must remove parent child-reference records"),('enforceAppCheck: true',"Trusted callable functions must enforce App Check")]:
    if needle not in functions: errors.append(msg)
fn=ROOT/'functions/index.js'
if fn.exists() and subprocess.run(['node','--check',str(fn)],capture_output=True,text=True).returncode != 0:
    errors.append('functions/index.js failed Node syntax check')
for p in list((ROOT/'functions').rglob('*.js')) + list((ROOT/'app/src/main').rglob('*.kt')):
    if '\\n' in p.read_text(errors='ignore'): errors.append(f"Literal \\n escape found in {p.relative_to(ROOT)}")
if errors:
    print("RELEASE GATE: FAIL")
    for e in errors: print(" -",e)
    sys.exit(1)
print(f"RELEASE GATE: PASS (V{expected_code})")
