#!/usr/bin/env python3
"""Fast source-level production smoke checks for Smart Students."""
from pathlib import Path
import re, sys
ROOT = Path(__file__).resolve().parents[1]
errors=[]

version=(ROOT/"VERSION").read_text().strip()
m=re.fullmatch(r"V(\d+)", version)
gradle=(ROOT/"app/build.gradle.kts").read_text(errors="ignore")
if not m or not re.search(rf"versionCode\s*=\s*{int(m.group(1))}\b", gradle):
    errors.append("VERSION/versionCode mismatch")

auth=(ROOT/"app/src/main/java/com/smartstudents/app/auth/AuthRepository.kt").read_text(errors="ignore")
for needle in ["normalizeEmail", "validateEmail", "validatePassword"]:
    if needle not in auth: errors.append(f"Auth validation missing: {needle}")

main=(ROOT/"app/src/main/java/com/smartstudents/app/MainActivity.kt").read_text(errors="ignore")
for needle,msg in [
    ("FirebaseAuth.AuthStateListener","Firebase auth state listener missing"),
    ("removeAuthStateListener","Firebase auth listener cleanup missing"),
    ('NotificationRegistration.subscribe(context)',"Notification registration missing"),
]:
    if needle not in main: errors.append(msg)

profile=(ROOT/"app/src/main/java/com/smartstudents/app/ui/ProfileSettingsScreen.kt").read_text(errors="ignore")
for needle in ["Privacy & data","Delete account","Logout"]:
    if needle not in profile: errors.append(f"Profile action missing: {needle}")

manifest=(ROOT/"app/src/main/AndroidManifest.xml").read_text(errors="ignore")
if "android.permission.INTERNET" not in manifest: errors.append("INTERNET permission missing")

if errors:
    print("FINAL SOURCE SMOKE: FAIL")
    for e in errors: print(" -", e)
    sys.exit(1)
print(f"FINAL SOURCE SMOKE: PASS ({version})")
