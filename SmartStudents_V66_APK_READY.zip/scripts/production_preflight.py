#!/usr/bin/env python3
"""Smart Students V41 local production preflight.

This does not require Firebase credentials and does not build the Android app.
It verifies the repository is ready for a real CI/Android Studio build.
"""
from pathlib import Path
import re, shutil, subprocess, sys

ROOT = Path(__file__).resolve().parents[1]
errors=[]; warnings=[]

gradle=ROOT/"app/build.gradle.kts"
version=(ROOT/"VERSION").read_text().strip()
text=gradle.read_text(errors="ignore")
mver=re.fullmatch(r"V(\d+)", version)
expected_code=int(mver.group(1)) if mver else None
if expected_code is None: errors.append(f"Invalid VERSION: {version}")
if expected_code is not None and not re.search(rf"versionCode\s*=\s*{expected_code}\b", text):
    errors.append("versionCode does not match VERSION")
if not re.search(r'versionName\s*=\s*"1\.0\.0"', text): warnings.append("Review versionName before Play Store release")

for p in [ROOT/"firestore.rules", ROOT/"storage.rules", ROOT/"functions/index.js"]:
    if not p.exists(): errors.append(f"Missing required backend file: {p.relative_to(ROOT)}")

workflow=(ROOT/".github/workflows/android-release.yml").read_text(errors="ignore")
if "path: app/build/outputs/apk/debug/*.apk" not in workflow:
    errors.append("CI debug APK artifact path is incorrect")
if "rm -f app/google-services.json release.keystore" not in workflow:
    errors.append("CI must remove temporary Firebase/signing credentials")

if (ROOT/"gradlew").exists():
    warnings.append("Gradle wrapper present; use ./gradlew for reproducible builds")
else:
    warnings.append("No Gradle wrapper committed; CI uses installed Gradle. Add a wrapper before long-term reproducibility.")

if shutil.which("node"):
    r=subprocess.run(["node","--check",str(ROOT/"functions/index.js")],capture_output=True,text=True)
    if r.returncode: errors.append("functions/index.js failed Node syntax check")
else:
    warnings.append("Node is not installed; JavaScript syntax was not checked locally")

for p in ROOT.rglob("*"):
    if p.is_file() and ".git" not in p.parts and p.suffix in {".kt",".kts",".js",".json",".properties",".xml"}:
        try: t=p.read_text(errors="ignore")
        except Exception: continue
        if "BEGIN PRIVATE KEY" in t or re.search(r"AIza[0-9A-Za-z_-]{20,}",t):
            errors.append(f"Possible credential in {p.relative_to(ROOT)}")

if errors:
    print("PRODUCTION PREFLIGHT: FAIL")
    for e in errors: print(" -",e)
    sys.exit(1)
print("PRODUCTION PREFLIGHT: PASS")
for w in warnings: print(" - WARNING:",w)
