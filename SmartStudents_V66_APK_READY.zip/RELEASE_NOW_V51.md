# SmartStudents V51 — Release Now

V51 is the release-handoff build. The workflow is now focused on one production path:

1. Run release/preflight/source-smoke gates.
2. Verify signing and Firebase configuration secrets.
3. Build the signed production AAB.
4. Verify the AAB exists, is non-empty, contains signing metadata, and generate SHA-256.
5. Deploy Firestore rules, Storage rules and Functions when enabled.
6. Publish the exact built AAB to Google Play Internal testing when `publish_internal=true`.
7. Upload the AAB and checksum as workflow artifacts.
8. Remove temporary production credentials.

### Workflow dispatch

Use **Android build → Run workflow** with:
- `build_release = true`
- `deploy_firebase = true`
- `publish_internal = true` once the Play service account is configured.

Required secrets:
- `SMARTSTUDENTS_KEYSTORE_BASE64`
- `SMARTSTUDENTS_KEYSTORE_PASSWORD`
- `SMARTSTUDENTS_KEY_ALIAS`
- `SMARTSTUDENTS_KEY_PASSWORD`
- `GOOGLE_SERVICES_JSON_B64`
- `FIREBASE_SERVICE_ACCOUNT_JSON`
- `FIREBASE_PROJECT_ID`
- `GOOGLE_PLAY_SERVICE_ACCOUNT_JSON` (for Internal testing)

The repository cannot perform the account-authorized Play/Firebase deployment by itself; GitHub Actions performs it only with the owner's configured secrets and authorization.
