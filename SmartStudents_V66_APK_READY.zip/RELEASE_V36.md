# Smart Students V36 — Production hardening

V36 is a release-hardening pass rather than a new feature release.

## Changes
- Isolated the offline progress queue by Firebase UID.
- Cleared queued progress on logout.
- Corrected the GitHub Actions debug APK artifact path.
- Added cleanup of temporary Firebase and signing credentials in CI.
- Added `scripts/production_preflight.py`.
- Bumped versionCode to 36.

## Verification
Run:
```bash
python scripts/release_gate.py
python scripts/production_preflight.py
```

Then perform the real Android/Firebase QA on a physical device before publishing.
