# Smart Students V26 Release Checklist

- [ ] Add Firebase `google-services.json` to `app/`.
- [ ] Enable Analytics and Crashlytics in Firebase.
- [ ] Deploy Functions, Firestore and Storage rules.
- [ ] Verify Analytics DebugView events.
- [ ] Trigger and verify a test Crashlytics report on a test build only.
- [ ] Test login, course/lesson, quiz, offline progress, sync retry and FCM.
- [ ] Remove test accounts/data.
- [ ] Configure signing for the release AAB.
- [ ] Run final Play Console pre-launch checks.
