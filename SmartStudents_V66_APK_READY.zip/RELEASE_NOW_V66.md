# SmartStudents V66 — Internal Testing Release Candidate

V66 keeps V65 as the release baseline and fixes the Internal Testing workflow ordering.

## Release-critical fix
The Internal Testing preflight now runs **after** the exact verified AAB is copied to `PLAY-PUBLISH.aab`. The preflight also derives the expected versionCode from `app/build.gradle.kts` instead of hard-coding a previous version.

## Intended path
1. Release readiness gates
2. Production credentials validation
3. Signed production AAB
4. SHA-256 verification
5. Immutable manifest
6. Exact AAB lock for Play
7. Internal Testing preflight
8. Google Play Internal track upload
9. Release artifacts + credential cleanup

Local environment cannot perform the actual Google Play upload because the owner's GitHub/Google Play secrets are not available here.
