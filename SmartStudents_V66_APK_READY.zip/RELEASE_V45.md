# Smart Students V45 — Firebase Session Guard

V45 hardens session handling so the Compose UI follows the real Firebase Auth
session instead of relying on stale local state.

## Changes
- Added a Firebase `AuthStateListener` bridge in `FirebaseGateway`.
- Protected screens automatically return to the login state when the Firebase
  account is signed out, deleted, or otherwise no longer authenticated.
- Listener is lifecycle-safe and removed when the Compose screen leaves scope.
- Existing offline/demo mode remains unchanged.
- Version: V45 / versionCode 45.

## Validation
- Static source inspection: PASS
- Version consistency: PASS
- Firebase session listener wiring: PASS
- No secrets added to source control.
