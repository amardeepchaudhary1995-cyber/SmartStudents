# Smart Students V41 — Account-Isolated Local Progress

V41 fixes a privacy/data-integrity issue in the local progress store.

## Changes
- Local lesson completion and quiz scores are now namespaced by the active Firebase UID.
- Demo/offline mode uses a separate `demo` namespace.
- A second account on the same device can no longer see the previous account's locally cached progress.
- Existing Firebase sync-queue UID scoping remains intact.
- Version code bumped to 41.

## Validation
- Static source inspection performed.
- Local progress keys verified to include an account namespace.
- Firebase sync queue remains UID-scoped.
- Android APK/AAB compilation still requires an Android SDK/Gradle environment; this workspace does not contain the Android SDK.
