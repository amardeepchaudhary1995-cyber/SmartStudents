# Smart Students V30 — Production Security Gate

V30 is the production-security step after V29 release engineering.

## Added
- Firebase App Check using **Play Integrity** on Android.
- App Check initialization only when Firebase is configured, preserving offline/demo mode.
- `submitProgress` callable function now requires valid App Check.
- Version 30.
- Local release-gate script for version, App Check dependency, and secret-file/API-key hygiene.

## Firebase console steps before production
1. Register the production Android app in Firebase.
2. Enable **App Check** for the Android app and select Play Integrity.
3. Configure the Play Integrity/Google Cloud project as required by Firebase App Check.
4. In Firebase App Check, monitor metrics before enforcing other Firebase products.
5. Enable enforcement for Firestore/Storage only after real-device QA confirms legitimate traffic.
6. Deploy functions after App Check is configured:
   `npm install --prefix functions`
   `firebase deploy --only functions`
7. Keep `google-services.json` and the release keystore out of Git.

## Local gate
From the `ss15` directory:
```bash
python scripts/release_gate.py
```

## Important
A signed production AAB still requires the owner's Firebase project and release keystore. This ZIP intentionally contains neither.
