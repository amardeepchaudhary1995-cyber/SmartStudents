# SmartStudents V65 — Internal Testing Release

V65 is the release candidate for Google Play Internal testing.

## Workflow
1. Run **Android release** with `build_release=true`.
2. Keep `publish_internal=true` and select `deploy_firebase=true` when backend deployment is required.
3. The workflow validates signing/external credentials, builds the signed AAB, verifies SHA-256, creates the immutable manifest, locks the exact AAB, then runs an Internal Testing preflight.
4. Only after that preflight does Google Play Internal testing upload run.

## Required GitHub secrets
- SMARTSTUDENTS_KEYSTORE_BASE64
- SMARTSTUDENTS_KEYSTORE_PASSWORD
- SMARTSTUDENTS_KEY_ALIAS
- SMARTSTUDENTS_KEY_PASSWORD
- GOOGLE_SERVICES_JSON_B64
- GOOGLE_PLAY_SERVICE_ACCOUNT_JSON
- FIREBASE_SERVICE_ACCOUNT_JSON (when Firebase deployment is enabled)
- FIREBASE_PROJECT_ID (when Firebase deployment is enabled)

This repository cannot execute the Play upload without the owner's GitHub/Google Play credentials.
