# Smart Students V39 — Release Candidate Integrity Pass

V39 hardens the production release pipeline so a production signed AAB is only attempted when all required Firebase and signing secrets are available.

## Changes
- Version bumped to V39 / versionCode 39.
- Release gate derives the expected versionCode from `VERSION`, preventing stale hard-coded checks.
- Production preflight uses the same version source.
- GitHub Actions only attempts the production AAB when all required keystore secrets **and** the Firebase configuration secret are present.
- Credential/secret scans include CI YAML files.
- Existing App Check, account isolation, offline queue isolation, parent-link and account-deletion checks remain enforced.

## Required CI secrets
- `SMARTSTUDENTS_KEYSTORE_BASE64`
- `SMARTSTUDENTS_KEYSTORE_PASSWORD`
- `SMARTSTUDENTS_KEY_ALIAS`
- `SMARTSTUDENTS_KEY_PASSWORD`
- `GOOGLE_SERVICES_JSON_B64`

No real credentials are included in this ZIP.

## Verification
```bash
python scripts/release_gate.py
python scripts/production_preflight.py
```

An actual Android APK/AAB build must run on Android Studio or CI with Android SDK and Gradle available.

## Additional source fixes
During the V39 static compile gate, two duplicate top-level Kotlin declarations were found and removed:
- obsolete `AdminModels.kt` duplicated `AdminCourseDraft`;
- obsolete `StudentDashboard.kt` duplicated `DashboardCard`.

These were source-level compile blockers, not just documentation issues.
