# Smart Students V42 — Authentication Session Integrity

V42 hardens startup authentication state.

## Changes
- Firebase cloud mode now treats the active Firebase session as the source of truth.
- A stale `logged_in` SharedPreferences flag can no longer open the learning area when Firebase has no authenticated user.
- This protects against stale local sessions after sign-out, token/session invalidation, or account removal.
- Offline/demo mode keeps its existing local login behavior.
- Version code bumped to 42.

## Validation
- Static source inspection performed.
- Release gate and production preflight executed.
- Android APK/AAB compilation still requires Android SDK/Gradle in the build environment.
