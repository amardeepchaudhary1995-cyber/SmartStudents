# SmartStudents V64 — Release Candidate

V64 keeps V63 as the release candidate and hardens the workflow for faster, safer execution.

## V64 change
The release workflow now validates the requested Firebase and Google Play service-account credentials **before** the signed AAB build. This prevents wasting CI build time when an external publishing credential is missing or malformed.

## Release path
1. Run `Android release` manually.
2. Keep `build_release=true`.
3. Keep `deploy_firebase=true` if backend rules/functions should deploy.
4. Keep `publish_internal=true` for Play Internal testing.
5. `run_debug_smoke=false` for the fastest release path.
6. The workflow builds and cryptographically verifies the signed AAB before external publish.
7. Firebase and Play publishing only proceed after the release candidate verification gate passes.

## Required GitHub secrets
- `SMARTSTUDENTS_KEYSTORE_BASE64`
- `SMARTSTUDENTS_KEYSTORE_PASSWORD`
- `SMARTSTUDENTS_KEY_ALIAS`
- `SMARTSTUDENTS_KEY_PASSWORD`
- `GOOGLE_SERVICES_JSON_B64`
- `FIREBASE_SERVICE_ACCOUNT_JSON` (when Firebase deploy is enabled)
- `FIREBASE_PROJECT_ID` (when Firebase deploy is enabled)
- `GOOGLE_PLAY_SERVICE_ACCOUNT_JSON` (when Internal testing publish is enabled)
