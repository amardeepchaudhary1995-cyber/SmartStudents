# SmartStudents V66 — APK Build

## GitHub Actions (recommended)

This project includes `.github/workflows/build-debug-apk.yml`.

1. Push the project to a GitHub repository.
2. Open **Actions** → **SmartStudents Debug APK**.
3. Click **Run workflow**.
4. Wait for the job to finish.
5. Download the artifact **SmartStudents-V66-debug-apk** from the completed run.

The workflow installs/uses Gradle 8.9 on the GitHub runner, so a local Gradle installation is not required for the GitHub build.

**Google Play credentials are not required for this debug APK.**

## Local build

Install Android Studio with the Android SDK, then from the project root run:

```bash
gradle :app:assembleDebug
```

The APK is generated under `app/build/outputs/apk/debug/`.
