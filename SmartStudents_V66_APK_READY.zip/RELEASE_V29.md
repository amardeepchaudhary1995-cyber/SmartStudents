# Smart Students V29 — Production Release Candidate

## What is ready
- Version 29 / 1.0.0
- Conditional Firebase Gradle plugin loading
- Environment-based release signing
- CI workflow for debug APK and optional signed AAB
- Privacy policy draft
- Play Console Data Safety draft

## Build locally
From `ss15/`, use a Gradle installation:

```bash
gradle :app:assembleDebug
```

For a signed AAB, set:
- `SMARTSTUDENTS_KEYSTORE_FILE`
- `SMARTSTUDENTS_KEYSTORE_PASSWORD`
- `SMARTSTUDENTS_KEY_ALIAS`
- `SMARTSTUDENTS_KEY_PASSWORD`

and place the production `google-services.json` in `app/`.

Then:

```bash
gradle :app:bundleRelease
```

## Important
Do not commit:
- `app/google-services.json` if your repository policy forbids it;
- release keystore/private keys;
- passwords, service-account JSON files, or CI secrets.

## Final gate
The app is not considered Play-Store-ready until the signed AAB has been tested on real devices and the Play Console Data Safety, target audience, content rating and privacy-policy declarations have been reviewed by the owner.
