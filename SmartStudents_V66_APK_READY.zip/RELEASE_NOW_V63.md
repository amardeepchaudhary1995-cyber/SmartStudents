# SmartStudents V63 — Release Candidate

V63 is the V62 release candidate with final release-pipeline hardening.

## Key fix
The pre-publish AAB checksum verification now runs from the correct directory, preventing a false path failure immediately before Firebase/Google Play publishing.

## Provenance
The immutable manifest now records `applicationId=com.smartstudents.app` alongside version, versionCode, AAB filename, SHA-256, commit SHA, workflow run ID, workflow name, and event.

## Release status
Repository gates are expected to pass locally. Actual signed AAB/Play publishing still requires the configured GitHub production secrets and an authorized workflow run.
