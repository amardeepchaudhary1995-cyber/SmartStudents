# SmartStudents V53 — Release Now

V53 keeps the project on the actual release path. No feature detour.

## One-click release flow
1. Run the GitHub Actions **Android release** workflow manually.
2. Keep `build_release=true`, `deploy_firebase=true`, and `publish_internal=true`.
3. The workflow validates all production credentials before building.
4. It builds the signed production AAB with Gradle 8.9.
5. It verifies the AAB, creates SHA-256 and an immutable release manifest.
6. It deploys Firebase rules/storage/functions.
7. It publishes the exact AAB to Google Play Internal testing.
8. It writes a release summary and uploads AAB/checksum/manifest artifacts.
9. Temporary production credentials are removed even on failure.

## Required GitHub secrets
`SMARTSTUDENTS_KEYSTORE_BASE64`, `SMARTSTUDENTS_KEYSTORE_PASSWORD`, `SMARTSTUDENTS_KEY_ALIAS`, `SMARTSTUDENTS_KEY_PASSWORD`, `GOOGLE_SERVICES_JSON_B64`, `FIREBASE_SERVICE_ACCOUNT_JSON`, `FIREBASE_PROJECT_ID`, and `GOOGLE_PLAY_SERVICE_ACCOUNT_JSON`.

## Owner-side final gate
The authorized GitHub/Firebase/Google Play accounts must supply these secrets and a physical-device QA pass. The repository does not bypass account authorization.
