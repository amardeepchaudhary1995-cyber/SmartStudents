package com.smartstudents.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.smartstudents.app.notifications.AnnouncementRepository

@Composable
fun AdminAnnouncementsScreen(repo: AnnouncementRepository, onBack:()->Unit) {
    var title by remember{mutableStateOf("")}; var body by remember{mutableStateOf("")}; var message by remember{mutableStateOf("")}; var busy by remember{mutableStateOf(false)}
    Column(Modifier.fillMaxSize().padding(20.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        Text("Publish Announcement",style=MaterialTheme.typography.headlineSmall)
        OutlinedTextField(title,{title=it},Modifier.fillMaxWidth(),label={Text("Title")})
        OutlinedTextField(body,{body=it},Modifier.fillMaxWidth(),minLines=4,label={Text("Message")})
        Button(
            onClick={
                busy=true; repo.publish(title.trim(),body.trim()){ok,e->busy=false;message=if(ok)"Published successfully." else (e?:"Publish failed")}
            },
            modifier=Modifier.fillMaxWidth(),
            enabled=!busy&&title.isNotBlank()&&body.isNotBlank()
        ){Text(if(busy)"Publishing…" else "Publish")}
        if(message.isNotBlank()) Text(message)
        OutlinedButton(onClick=onBack, modifier=Modifier.fillMaxWidth()){Text("Back")}
    }
}
